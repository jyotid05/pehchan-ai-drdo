#!/usr/bin/env python3
"""
Gender Configuration for Pehchan AI
Easy configuration to fix gender prediction accuracy
"""

# =============================================================================
# GENDER INTERPRETATION SETTINGS
# =============================================================================

# CRITICAL: Choose the correct interpretation based on your model's training
# Test both options and use the one that gives correct results

# Option A: Standard interpretation (0=Female, 1=Male)
# This is the most common format in datasets like UTKFace, IMDB-WIKI, etc.
GENDER_INTERPRETATION = "A"

# Option B: Inverted interpretation (0=Male, 1=Female)
# Use this if Option A gives inverted results
# GENDER_INTERPRETATION = "B"

# =============================================================================
# GENDER MAPPING FUNCTIONS
# =============================================================================

def get_gender_from_binary_classification(probs):
    """
    Get gender from binary classification output [prob_class0, prob_class1]
    
    Args:
        probs: Array of [prob_class0, prob_class1]
        
    Returns:
        Tuple of (gender_label, confidence)
    """
    import numpy as np
    
    predicted_class = np.argmax(probs)
    confidence = float(np.max(probs))
    
    if GENDER_INTERPRETATION == "A":
        # Standard: 0=Female, 1=Male
        gender_label = "Male" if predicted_class == 1 else "Female"
    else:
        # Inverted: 0=Male, 1=Female
        gender_label = "Female" if predicted_class == 1 else "Male"
    
    return gender_label, confidence

def get_gender_from_single_value(value):
    """
    Get gender from single sigmoid output (0-1 range)
    
    Args:
        value: Single float value between 0 and 1
        
    Returns:
        Tuple of (gender_label, confidence)
    """
    confidence = max(value, 1 - value)  # Distance from 0.5
    
    if GENDER_INTERPRETATION == "A":
        # Standard: 0=Female, 1=Male
        gender_label = "Male" if value > 0.5 else "Female"
    else:
        # Inverted: 0=Male, 1=Female
        gender_label = "Female" if value > 0.5 else "Male"
    
    return gender_label, confidence

def get_gender_from_multi_class(output):
    """
    Get gender from multi-class output (for models with more than 2 outputs)
    
    Args:
        output: Array of class probabilities
        
    Returns:
        Tuple of (gender_label, confidence)
    """
    import numpy as np
    
    predicted_class = np.argmax(output)
    confidence = float(np.max(output))
    
    # Assume first two classes are gender-related
    if GENDER_INTERPRETATION == "A":
        if predicted_class == 0:
            gender_label = "Female"
        elif predicted_class == 1:
            gender_label = "Male"
        else:
            gender_label = "Unknown"
    else:
        if predicted_class == 0:
            gender_label = "Male"
        elif predicted_class == 1:
            gender_label = "Female"
        else:
            gender_label = "Unknown"
    
    return gender_label, confidence

# =============================================================================
# TESTING FUNCTIONS
# =============================================================================

def test_gender_interpretations():
    """Test both interpretations with sample data"""
    
    print("=" * 50)
    print("GENDER INTERPRETATION TESTING")
    print("=" * 50)
    
    # Test binary classification
    print("\n1. Binary Classification Test:")
    test_probs = [[0.8, 0.2], [0.3, 0.7], [0.6, 0.4]]
    
    for i, probs in enumerate(test_probs):
        print(f"   Sample {i+1}: {probs}")
        
        # Test interpretation A
        global GENDER_INTERPRETATION
        GENDER_INTERPRETATION = "A"
        gender_a, conf_a = get_gender_from_binary_classification(probs)
        
        # Test interpretation B
        GENDER_INTERPRETATION = "B"
        gender_b, conf_b = get_gender_from_binary_classification(probs)
        
        print(f"      Interpretation A: {gender_a} (confidence: {conf_a:.3f})")
        print(f"      Interpretation B: {gender_b} (confidence: {conf_b:.3f})")
    
    # Test single value
    print("\n2. Single Value Test:")
    test_values = [0.2, 0.7, 0.5]
    
    for i, value in enumerate(test_values):
        print(f"   Sample {i+1}: {value}")
        
        # Test interpretation A
        GENDER_INTERPRETATION = "A"
        gender_a, conf_a = get_gender_from_single_value(value)
        
        # Test interpretation B
        GENDER_INTERPRETATION = "B"
        gender_b, conf_b = get_gender_from_single_value(value)
        
        print(f"      Interpretation A: {gender_a} (confidence: {conf_a:.3f})")
        print(f"      Interpretation B: {gender_b} (confidence: {conf_b:.3f})")
    
    # Reset to default
    GENDER_INTERPRETATION = "A"
    
    print("\n" + "=" * 50)
    print("INSTRUCTIONS:")
    print("=" * 50)
    print("""
1. Test your model with known male/female images
2. Compare results with both interpretations
3. Update GENDER_INTERPRETATION in this file to the correct one
4. The enhanced_app.py will automatically use the correct interpretation
""")

# =============================================================================
# CONFIGURATION VALIDATION
# =============================================================================

def validate_config():
    """Validate the current configuration"""
    
    if GENDER_INTERPRETATION not in ["A", "B"]:
        raise ValueError("GENDER_INTERPRETATION must be 'A' or 'B'")
    
    print(f"✅ Gender interpretation set to: {GENDER_INTERPRETATION}")
    
    if GENDER_INTERPRETATION == "A":
        print("   Using standard mapping: 0=Female, 1=Male")
    else:
        print("   Using inverted mapping: 0=Male, 1=Female")

if __name__ == "__main__":
    print("🔧 Gender Configuration Tool")
    validate_config()
    test_gender_interpretations()
    
    print("\n💡 To fix gender predictions:")
    print("1. Run your model with known images")
    print("2. If results are wrong, change GENDER_INTERPRETATION to 'B'")
    print("3. Restart the enhanced_app.py")
    print("4. Test again until gender predictions are correct")
