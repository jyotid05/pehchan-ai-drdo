#!/usr/bin/env python3
"""
Simple test server for Pehchan AI interface
Uses only built-in Python modules
"""

import json
import random
from datetime import datetime
from http.server import HTTPServer, SimpleHTTPRequestHandler
import urllib.parse

class PehchanAIHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.path = '/index.html'
        elif self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            status = {
                'status': 'ready',
                'model_loaded': True,
                'timestamp': datetime.now().isoformat(),
                'version': '1.0.0-simple-test'
            }
            self.wfile.write(json.dumps(status).encode())
            return
        
        return super().do_GET()
    
    def do_POST(self):
        if self.path == '/api/predict':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                data = json.loads(post_data.decode('utf-8'))
                
                # Mock prediction with realistic age distribution
                age_ranges = [
                    (3, 12),    # Child
                    (13, 19),   # Teenager
                    (20, 29),   # Young Adult
                    (30, 44),   # Adult
                    (45, 59),   # Middle-aged
                    (60, 80)    # Senior
                ]
                age_range = random.choice(age_ranges)
                age = random.randint(age_range[0], age_range[1])

                result = {
                    'age': age,
                    'gender': random.choice(['Male', 'Female']),
                    'confidence': round(random.uniform(0.75, 0.95), 2),
                    'timestamp': datetime.now().isoformat(),
                    'bbox': {
                        'x': random.randint(50, 150),
                        'y': random.randint(50, 100),
                        'width': random.randint(180, 220),
                        'height': random.randint(220, 280)
                    }
                }
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())
                
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error = {'error': str(e)}
                self.wfile.write(json.dumps(error).encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

if __name__ == '__main__':
    server = HTTPServer(('localhost', 8000), PehchanAIHandler)
    print("Simple test server running at http://localhost:8000")
    print("Open your browser and navigate to http://localhost:8000")
    server.serve_forever()
