#!/usr/bin/env python3
"""
Test version of Pehchan AI Flask Backend
This version works without the actual model for testing the interface
"""

import os
import io
import base64
import logging
import random
from datetime import datetime
import numpy as np
from PIL import Image
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

class MockPehchanAIModel:
    """
    Mock model for testing the interface without actual AI model
    """
    
    def __init__(self):
        self.is_loaded = True
        logger.info("Mock model initialized successfully")
    
    def predict(self, image):
        """
        Mock prediction that returns random but realistic values
        """
        # Simulate processing time
        import time
        time.sleep(0.1)
        
        # Generate realistic mock predictions
        predicted_age = random.randint(18, 65)
        gender_options = ["Male", "Female"]
        predicted_gender = random.choice(gender_options)
        confidence = random.uniform(0.7, 0.95)
        
        result = {
            'age': predicted_age,
            'gender': predicted_gender,
            'confidence': confidence,
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"Mock prediction result: {result}")
        return result

# Initialize the mock model
ai_model = MockPehchanAIModel()

@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    """Serve static files (CSS, JS)"""
    return send_from_directory('.', filename)

@app.route('/api/status')
def get_status():
    """
    Get the current status of the AI system
    """
    try:
        status = {
            'status': 'ready',
            'model_loaded': True,
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0-test'
        }
        return jsonify(status)
    except Exception as e:
        logger.error(f"Status check failed: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/predict', methods=['POST'])
def predict():
    """
    Mock prediction endpoint for testing
    """
    try:
        # Get JSON data
        data = request.get_json()
        if not data or 'image' not in data:
            return jsonify({'error': 'No image data provided'}), 400
        
        # Decode base64 image (just for validation)
        try:
            image_data = base64.b64decode(data['image'])
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGB if needed
            if image.mode != 'RGB':
                image = image.convert('RGB')
                
        except Exception as e:
            logger.error(f"Image decoding failed: {str(e)}")
            return jsonify({'error': 'Invalid image data'}), 400
        
        # Make mock prediction
        result = ai_model.predict(image)
        return jsonify(result)
            
    except Exception as e:
        logger.error(f"Request processing failed: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    logger.info("Starting Pehchan AI Test Flask server...")
    logger.info("Access the application at: http://localhost:5001")
    
    app.run(
        host='0.0.0.0',
        port=5001,
        debug=True,
        threaded=True
    )
