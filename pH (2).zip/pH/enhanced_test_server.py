#!/usr/bin/env python3
"""
Enhanced Test Server for Pehchan AI
Simulates the enhanced backend with face detection and prediction smoothing
"""

import json
import random
import time
from datetime import datetime, timedelta
from collections import defaultdict, Counter
from http.server import HTTPServer, SimpleHTTPRequestHandler
import urllib.parse

class MockPredictionBuffer:
    """Mock version of the prediction buffer for testing"""
    
    def __init__(self):
        self.predictions = defaultdict(list)
        self.face_counter = 0
        
    def add_prediction(self, face_id, prediction):
        """Add a prediction to the buffer"""
        timestamp = datetime.now()
        self.predictions[face_id].append((timestamp, prediction))
        
        # Keep only last 20 seconds
        cutoff = timestamp - timedelta(seconds=20)
        self.predictions[face_id] = [
            (ts, pred) for ts, pred in self.predictions[face_id]
            if ts > cutoff
        ]
    
    def get_stable_prediction(self, face_id):
        """Get stable prediction using majority voting"""
        if face_id not in self.predictions or not self.predictions[face_id]:
            return None
            
        recent = self.predictions[face_id]
        if not recent:
            return None
            
        # Extract predictions
        age_groups = [pred['age_group'] for _, pred in recent]
        genders = [pred['gender'] for _, pred in recent]
        confidences = [pred['confidence'] for _, pred in recent]
        
        # Find most common
        most_common_age = Counter(age_groups).most_common(1)[0][0]
        most_common_gender = Counter(genders).most_common(1)[0][0]
        avg_confidence = sum(confidences) / len(confidences)
        
        return {
            'age_group': most_common_age,
            'gender': most_common_gender,
            'confidence': avg_confidence,
            'sample_count': len(recent),
            'stability_score': max(Counter(age_groups).values()) / len(age_groups)
        }

class EnhancedTestHandler(SimpleHTTPRequestHandler):
    
    # Class-level buffer to persist across requests
    buffer = MockPredictionBuffer()
    
    def do_GET(self):
        if self.path == '/':
            self.path = '/index.html'
        elif self.path == '/api/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            status = {
                'status': 'ready',
                'model_loaded': True,
                'face_detector_loaded': True,
                'buffer_active': True,
                'timestamp': datetime.now().isoformat(),
                'version': '2.0.0-enhanced-test'
            }
            self.wfile.write(json.dumps(status).encode())
            return
        elif self.path == '/api/buffer/status':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            buffer_info = {}
            for face_id, predictions in self.buffer.predictions.items():
                buffer_info[face_id] = {
                    'prediction_count': len(predictions),
                    'oldest_prediction': predictions[0][0].isoformat() if predictions else None,
                    'newest_prediction': predictions[-1][0].isoformat() if predictions else None
                }
            
            status = {
                'active_faces': len(buffer_info),
                'buffer_details': buffer_info,
                'buffer_duration': 20
            }
            self.wfile.write(json.dumps(status).encode())
            return
        
        return super().do_GET()
    
    def do_POST(self):
        if self.path == '/api/predict':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                data = json.loads(post_data.decode('utf-8'))
                
                # Simulate face detection (1-3 faces)
                num_faces = random.randint(1, 2)
                predictions = []
                
                for i in range(num_faces):
                    # Generate or reuse face ID
                    face_id = f"face_{i % 3}"  # Simulate consistent face tracking
                    
                    # Generate raw prediction with some variation
                    age_groups = ['Child', 'Teenager', 'Young Adult', 'Adult', 'Middle-aged', 'Senior']
                    
                    # Simulate some consistency for the same face
                    if face_id == "face_0":
                        # Primary face - more stable
                        base_age_group = random.choice(['Young Adult', 'Adult'])
                        base_gender = 'Male'
                    else:
                        # Secondary face - more variation
                        base_age_group = random.choice(age_groups)
                        base_gender = random.choice(['Male', 'Female'])
                    
                    # Add some noise to simulate model fluctuation
                    if random.random() < 0.2:  # 20% chance of different prediction
                        age_group = random.choice(age_groups)
                        gender = random.choice(['Male', 'Female'])
                    else:
                        age_group = base_age_group
                        gender = base_gender
                    
                    raw_prediction = {
                        'age_group': age_group,
                        'gender': gender,
                        'confidence': random.uniform(0.7, 0.95)
                    }
                    
                    # Add to buffer
                    self.buffer.add_prediction(face_id, raw_prediction)
                    
                    # Get stable prediction
                    stable_prediction = self.buffer.get_stable_prediction(face_id)
                    
                    if stable_prediction:
                        prediction_result = {
                            'face_id': face_id,
                            'bbox': [
                                random.randint(50, 200),  # x
                                random.randint(50, 150),  # y
                                random.randint(150, 250), # width
                                random.randint(180, 280)  # height
                            ],
                            'stable_prediction': stable_prediction,
                            'raw_prediction': raw_prediction,
                            'timestamp': datetime.now().isoformat()
                        }
                        predictions.append(prediction_result)
                
                result = {
                    'faces_detected': len(predictions),
                    'predictions': predictions,
                    'timestamp': datetime.now().isoformat()
                }
                
                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                self.wfile.write(json.dumps(result).encode())
                
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-type', 'application/json')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                error = {'error': str(e)}
                self.wfile.write(json.dumps(error).encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

if __name__ == '__main__':
    server = HTTPServer(('localhost', 8001), EnhancedTestHandler)
    print("Enhanced test server running at http://localhost:8001")
    print("Features: Mock face detection + 20-second buffer + prediction smoothing")
    print("Open your browser and navigate to http://localhost:8001")
    server.serve_forever()
