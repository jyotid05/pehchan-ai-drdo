#!/usr/bin/env python3
"""
Model Debugging Script for Pehchan AI
This script helps analyze your trained .keras model to understand its exact format
"""

import os
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

def analyze_model(model_path):
    """Analyze the model structure and test with sample data"""
    
    print("=" * 60)
    print("PEHCHAN AI MODEL ANALYSIS")
    print("=" * 60)
    
    # Check if model exists
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        return
    
    try:
        # Load model
        print(f"📁 Loading model from: {model_path}")
        model = tf.keras.models.load_model(model_path)
        print("✅ Model loaded successfully!")
        
        # Basic model info
        print("\n📊 BASIC MODEL INFORMATION:")
        print(f"   Model type: {type(model).__name__}")
        print(f"   Number of layers: {len(model.layers)}")
        
        # Input analysis
        print("\n🔍 INPUT ANALYSIS:")
        if hasattr(model, 'input_shape'):
            if isinstance(model.input_shape, list):
                print(f"   Multiple inputs: {len(model.input_shape)}")
                for i, shape in enumerate(model.input_shape):
                    print(f"   Input {i}: {shape}")
            else:
                print(f"   Input shape: {model.input_shape}")
                if len(model.input_shape) >= 4:
                    batch, height, width, channels = model.input_shape
                    print(f"   Expected image size: {height}x{width} with {channels} channels")
        
        # Output analysis
        print("\n📤 OUTPUT ANALYSIS:")
        if hasattr(model, 'output_shape'):
            if isinstance(model.output_shape, list):
                print(f"   Multiple outputs: {len(model.output_shape)}")
                for i, shape in enumerate(model.output_shape):
                    print(f"   Output {i}: {shape}")
                    if shape[-1] == 1:
                        print(f"      → Likely regression output (age or single value)")
                    elif shape[-1] == 2:
                        print(f"      → Likely binary classification (gender: female/male)")
                    elif shape[-1] > 2:
                        print(f"      → Likely multi-class classification ({shape[-1]} classes)")
            else:
                print(f"   Single output: {model.output_shape}")
                if model.output_shape[-1] == 1:
                    print(f"      → Likely regression output")
                elif model.output_shape[-1] == 2:
                    print(f"      → Likely binary classification or [age, gender]")
                elif model.output_shape[-1] > 2:
                    print(f"      → Likely multi-class classification")
        
        # Layer analysis
        print("\n🏗️ LAYER ANALYSIS:")
        print("   Last few layers:")
        for i, layer in enumerate(model.layers[-5:]):
            print(f"   {len(model.layers)-5+i}: {layer.name} ({type(layer).__name__}) - Output: {layer.output_shape}")
        
        # Test with sample data
        print("\n🧪 TESTING WITH SAMPLE DATA:")
        test_sample_predictions(model)
        
        # Model summary
        print("\n📋 FULL MODEL SUMMARY:")
        model.summary()
        
    except Exception as e:
        print(f"❌ Error analyzing model: {str(e)}")

def test_sample_predictions(model):
    """Test the model with sample data to understand output format"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        # Create sample input
        if len(input_shape) >= 4:
            batch, height, width, channels = input_shape
            if height is None or width is None:
                height, width = 224, 224  # Default
            if channels is None:
                channels = 3  # Default
            
            sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
            print(f"   Created sample input: {sample_input.shape}")
            print(f"   Input range: [{sample_input.min():.3f}, {sample_input.max():.3f}]")
            
            # Make prediction
            predictions = model.predict(sample_input, verbose=0)
            
            print(f"   Prediction type: {type(predictions)}")
            
            if isinstance(predictions, list):
                print(f"   Multiple outputs ({len(predictions)}):")
                for i, pred in enumerate(predictions):
                    print(f"      Output {i}: shape={pred.shape}, values={pred[0]}")
                    analyze_output_values(pred[0], i)
            else:
                print(f"   Single output: shape={predictions.shape}")
                print(f"   Values: {predictions[0]}")
                analyze_output_values(predictions[0], 0)
                
        else:
            print("   ⚠️ Unexpected input shape format")
            
    except Exception as e:
        print(f"   ❌ Error testing predictions: {str(e)}")

def analyze_output_values(output, index):
    """Analyze what the output values might represent"""
    
    if len(output.shape) == 0:  # Scalar
        value = float(output)
        print(f"      → Scalar value: {value:.3f}")
        if 0 <= value <= 1:
            print(f"        Likely: probability or normalized value")
        elif 0 <= value <= 100:
            print(f"        Likely: age prediction")
        
    elif len(output.shape) == 1:  # Vector
        print(f"      → Vector with {len(output)} values: {output}")
        
        if len(output) == 1:
            value = float(output[0])
            if 0 <= value <= 1:
                print(f"        Likely: probability or binary classification")
            elif 0 <= value <= 100:
                print(f"        Likely: age prediction")
                
        elif len(output) == 2:
            print(f"        Likely: binary classification [class0_prob, class1_prob]")
            print(f"        Probabilities: {output}")
            print(f"        Predicted class: {np.argmax(output)} (confidence: {np.max(output):.3f})")
            
        elif len(output) > 2:
            print(f"        Likely: multi-class classification ({len(output)} classes)")
            print(f"        Predicted class: {np.argmax(output)} (confidence: {np.max(output):.3f})")

def create_test_image(size=(224, 224)):
    """Create a test image for debugging"""
    
    # Create a simple test pattern
    img = np.zeros((*size, 3), dtype=np.uint8)
    
    # Add some patterns
    img[size[0]//4:3*size[0]//4, size[1]//4:3*size[1]//4] = [100, 150, 200]  # Blue rectangle
    img[size[0]//3:2*size[0]//3, size[1]//3:2*size[1]//3] = [200, 100, 100]  # Red rectangle
    
    return img

def test_preprocessing_strategies(model_path):
    """Test different preprocessing strategies"""
    
    print("\n🔬 TESTING PREPROCESSING STRATEGIES:")
    
    try:
        model = tf.keras.models.load_model(model_path)
        
        # Get input size
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
            
        height = input_shape[1] if input_shape[1] is not None else 224
        width = input_shape[2] if input_shape[2] is not None else 224
        
        # Create test image
        test_img = create_test_image((height, width))
        
        strategies = [
            ("0-1 normalization", lambda x: x.astype(np.float32) / 255.0),
            ("-1 to 1 normalization", lambda x: (x.astype(np.float32) / 127.5) - 1.0),
            ("ImageNet normalization", lambda x: (x.astype(np.float32) / 255.0 - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])),
            ("No normalization", lambda x: x.astype(np.float32))
        ]
        
        for name, preprocess_fn in strategies:
            try:
                processed = preprocess_fn(test_img)
                processed_batch = np.expand_dims(processed, axis=0)
                
                predictions = model.predict(processed_batch, verbose=0)
                
                print(f"   {name}:")
                print(f"      Input range: [{processed.min():.3f}, {processed.max():.3f}]")
                
                if isinstance(predictions, list):
                    for i, pred in enumerate(predictions):
                        print(f"      Output {i}: {pred[0]}")
                else:
                    print(f"      Output: {predictions[0]}")
                    
            except Exception as e:
                print(f"   {name}: ❌ Error - {str(e)}")
                
    except Exception as e:
        print(f"   ❌ Error in preprocessing test: {str(e)}")

if __name__ == "__main__":
    model_path = "age_gender_model3 .keras"  # Note: space in filename
    
    print("🔍 Starting model analysis...")
    analyze_model(model_path)
    
    print("\n" + "=" * 60)
    test_preprocessing_strategies(model_path)
    
    print("\n" + "=" * 60)
    print("✅ Analysis complete!")
    print("\n💡 RECOMMENDATIONS:")
    print("1. Check the output analysis above to understand your model format")
    print("2. Note the input size requirements")
    print("3. Try different preprocessing strategies if predictions seem wrong")
    print("4. Update the enhanced_app.py based on your model's specific format")
    print("\n📝 Next steps:")
    print("- Run this script: python debug_model.py")
    print("- Use the output to configure enhanced_app.py correctly")
    print("- Test with your actual model for accurate predictions")
