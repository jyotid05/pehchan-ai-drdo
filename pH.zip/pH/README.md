# Pehchan AI - DRDO PXE
## Real-time Age & Gender Prediction System with Advanced UI

A professional web-based AI system for real-time age and gender prediction using webcam input, developed for DRDO PXE. Features advanced visual overlays, age group categorization with emojis, and military-themed interface design.

## Features

### 🎯 **Core Functionality**
- **Real-time Analysis**: Live webcam feed with predictions every 2 seconds
- **Age Group Classification**: Categorized with emoji indicators:
  - 🧒 Child (3–12)
  - 🧑‍🎓 Teenager (13–19)
  - 👨‍💼 Young Adult (20–29)
  - 🧔 Adult (30–44)
  - 👴 Middle-aged (45–59)
  - 👵 Senior (60+)
- **Gender Detection**: Male/Female classification with confidence scores
- **Face Detection**: Automatic face detection with bounding box overlay

### 🎨 **Advanced Visual Interface**
- **Glowing Title**: "Pehchan AI – DRDO PXE" with advanced animations
- **High-tech Background**: Radar lines, neural particles, and grid animations
- **Video Overlays**: Real-time bounding boxes and prediction labels on video feed
- **DRDO Military Theme**: Professional dark interface with cyan/blue accents
- **Responsive Design**: Works on desktop, tablet, and mobile devices

### 🔧 **Technical Features**
- **Real-time Metrics**: Processing rate, confidence scores, and system status
- **Error Handling**: Comprehensive error handling and user feedback
- **Modern Tech Stack**: Pure HTML/CSS/JS frontend with Flask backend
- **Face Detection**: OpenCV-based face detection with bounding box coordinates
- **Canvas Overlays**: Dynamic drawing of predictions directly on video feed

## System Requirements

- Python 3.8 or higher
- Modern web browser with webcam support
- Minimum 4GB RAM
- GPU recommended for better performance

## Installation

### 1. Clone or Download the Project
```bash
# If using git
git clone <repository-url>
cd pehchan-ai

# Or download and extract the files to a folder
```

### 2. Install Python Dependencies
```bash
# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Verify Model File
Ensure the `age_gender_model3.keras` file is in the project directory.

## Usage

### 1. Start the Flask Backend
```bash
python app.py
```

The server will start on `http://localhost:5000`

### 2. Access the Web Interface
Open your web browser and navigate to:
```
http://localhost:5000
```

### 3. Using the System
1. Click the **"Start Camera"** button to activate your webcam
2. Allow camera permissions when prompted
3. The system will begin real-time analysis automatically
4. View predictions in the right panel:
   - **Age**: Predicted age in years
   - **Gender**: Male/Female classification
   - **Confidence**: Prediction confidence percentage
5. Click **"Stop Camera"** to end the session

## File Structure

```
pehchan-ai/
├── index.html              # Main web interface
├── style.css               # DRDO-themed styling
├── script.js               # Frontend JavaScript logic
├── app.py                  # Flask backend server
├── requirements.txt        # Python dependencies
├── age_gender_model3.keras # AI model file
└── README.md              # This file
```

## API Endpoints

### GET /api/status
Returns system status and model availability.

**Response:**
```json
{
  "status": "ready",
  "model_loaded": true,
  "timestamp": "2024-01-01T12:00:00",
  "version": "1.0.0"
}
```

### POST /api/predict
Accepts base64 encoded image and returns predictions.

**Request:**
```json
{
  "image": "base64_encoded_image_data"
}
```

**Response:**
```json
{
  "age": 25.5,
  "gender": "Male",
  "confidence": 0.87,
  "timestamp": "2024-01-01T12:00:00"
}
```

## Troubleshooting

### Camera Access Issues
- Ensure your browser has camera permissions
- Check if another application is using the camera
- Try refreshing the page and allowing permissions again

### Model Loading Errors
- Verify the `age_gender_model3.keras` file exists
- Check Python dependencies are installed correctly
- Ensure sufficient RAM is available

### Backend Connection Issues
- Confirm Flask server is running on port 5000
- Check firewall settings
- Verify no other service is using port 5000

### Performance Issues
- Close unnecessary browser tabs
- Ensure adequate system resources
- Consider using a GPU for better performance

## Technical Details

### Frontend Technologies
- **HTML5**: Semantic structure with modern elements
- **CSS3**: Advanced animations, gradients, and responsive design
- **JavaScript ES6+**: Modern async/await, classes, and modules
- **WebRTC**: Camera access and media streaming

### Backend Technologies
- **Flask**: Lightweight Python web framework
- **TensorFlow**: AI model inference
- **OpenCV**: Image processing and computer vision
- **PIL/Pillow**: Image manipulation and format conversion

### Security Features
- CORS protection
- Input validation
- Error handling
- Resource cleanup

## Development

### Customizing the UI
- Modify `style.css` for visual changes
- Update `index.html` for structural changes
- Edit `script.js` for functionality changes

### Model Integration
- Replace `age_gender_model3.keras` with your model
- Update preprocessing in `app.py` if needed
- Adjust prediction parsing based on model output format

### Adding Features
- Extend API endpoints in `app.py`
- Add new UI components in `index.html`
- Implement frontend logic in `script.js`

## License

Developed for DRDO PXE. All rights reserved.

## Support

For technical support or questions, please contact the DRDO PXE development team.

---

**Pehchan AI v1.0** - Real-time Age & Gender Recognition System  
© 2024 Defence Research and Development Organisation (DRDO) - PXE
