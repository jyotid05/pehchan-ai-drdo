#!/usr/bin/env python3
"""
Gender Prediction Debugging Tool for Pehchan AI
This script specifically analyzes gender prediction accuracy and helps fix issues
"""

import os
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

def analyze_gender_predictions(model_path):
    """Analyze gender prediction behavior in detail"""
    
    print("=" * 60)
    print("GENDER PREDICTION ANALYSIS")
    print("=" * 60)
    
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        return
    
    try:
        # Load model
        print(f"📁 Loading model from: {model_path}")
        model = tf.keras.models.load_model(model_path)
        print("✅ Model loaded successfully!")
        
        # Analyze model outputs for gender
        print("\n🔍 GENDER OUTPUT ANALYSIS:")
        analyze_model_outputs(model)
        
        # Test with multiple samples
        print("\n🧪 TESTING GENDER PREDICTIONS:")
        test_gender_predictions(model)
        
        # Test different interpretations
        print("\n🔄 TESTING DIFFERENT GENDER INTERPRETATIONS:")
        test_gender_interpretations(model)
        
    except Exception as e:
        print(f"❌ Error analyzing model: {str(e)}")

def analyze_model_outputs(model):
    """Analyze model outputs specifically for gender information"""
    
    # Get output information
    if hasattr(model, 'output_shape'):
        if isinstance(model.output_shape, list):
            print(f"   Multiple outputs detected: {len(model.output_shape)}")
            for i, shape in enumerate(model.output_shape):
                print(f"   Output {i}: {shape}")
                analyze_output_for_gender(shape, i)
        else:
            print(f"   Single output: {model.output_shape}")
            analyze_output_for_gender(model.output_shape, 0)

def analyze_output_for_gender(shape, index):
    """Analyze what each output might represent for gender"""
    
    if len(shape) >= 2:
        output_size = shape[-1]
        
        if output_size == 1:
            print(f"      → Output {index}: Single value - likely binary gender (0=Female, 1=Male or vice versa)")
        elif output_size == 2:
            print(f"      → Output {index}: Two values - likely [Female_prob, Male_prob]")
        elif output_size > 2:
            print(f"      → Output {index}: {output_size} values - might include gender as one of the outputs")
        else:
            print(f"      → Output {index}: Unclear format")

def test_gender_predictions(model):
    """Test gender predictions with sample data"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        if len(input_shape) >= 4:
            batch, height, width, channels = input_shape
            if height is None or width is None:
                height, width = 224, 224
            if channels is None:
                channels = 3
            
            # Test with multiple random samples
            for i in range(5):
                print(f"\n   Sample {i+1}:")
                sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
                
                # Test different normalizations
                normalizations = [
                    ("0-1 norm", sample_input),
                    ("-1 to 1 norm", (sample_input * 2) - 1),
                    ("0-255 range", sample_input * 255)
                ]
                
                for norm_name, norm_input in normalizations:
                    try:
                        predictions = model.predict(norm_input, verbose=0)
                        gender_info = extract_gender_info(predictions)
                        print(f"      {norm_name}: {gender_info}")
                    except Exception as e:
                        print(f"      {norm_name}: Error - {str(e)}")
                        
    except Exception as e:
        print(f"   ❌ Error in gender testing: {str(e)}")

def extract_gender_info(predictions):
    """Extract gender information from model predictions"""
    
    gender_interpretations = []
    
    if isinstance(predictions, list):
        # Multiple outputs
        for i, pred in enumerate(predictions):
            interpretation = interpret_single_output(pred[0], f"Output_{i}")
            if interpretation:
                gender_interpretations.append(interpretation)
    else:
        # Single output
        interpretation = interpret_single_output(predictions[0], "Single_Output")
        if interpretation:
            gender_interpretations.append(interpretation)
    
    return gender_interpretations if gender_interpretations else ["No clear gender info"]

def interpret_single_output(output, output_name):
    """Interpret a single output for gender information"""
    
    if len(output.shape) == 0:  # Scalar
        value = float(output)
        if 0 <= value <= 1:
            return f"{output_name}: {value:.3f} (Binary: {'Male' if value > 0.5 else 'Female'})"
    
    elif len(output.shape) == 1:  # Vector
        if len(output) == 1:
            value = float(output[0])
            if 0 <= value <= 1:
                return f"{output_name}: {value:.3f} (Binary: {'Male' if value > 0.5 else 'Female'})"
        
        elif len(output) == 2:
            # Binary classification
            probs = output
            predicted_class = np.argmax(probs)
            confidence = np.max(probs)
            
            # Test both interpretations
            interp1 = "Male" if predicted_class == 1 else "Female"
            interp2 = "Female" if predicted_class == 1 else "Male"
            
            return f"{output_name}: [{probs[0]:.3f}, {probs[1]:.3f}] → Class {predicted_class} (Interp1: {interp1}, Interp2: {interp2}, Conf: {confidence:.3f})"
        
        elif len(output) > 2:
            # Multi-class - might have gender as one class
            max_idx = np.argmax(output)
            max_val = np.max(output)
            return f"{output_name}: Max at index {max_idx} with value {max_val:.3f}"
    
    return None

def test_gender_interpretations(model):
    """Test different ways to interpret gender predictions"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        if len(input_shape) >= 4:
            batch, height, width, channels = input_shape
            if height is None or width is None:
                height, width = 224, 224
            if channels is None:
                channels = 3
            
            # Create a test sample
            sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
            predictions = model.predict(sample_input, verbose=0)
            
            print("   Testing different gender interpretation strategies:")
            
            # Strategy 1: Multiple outputs
            if isinstance(predictions, list) and len(predictions) >= 2:
                print("\n   Strategy 1: Multiple outputs [age, gender]")
                age_output = predictions[0]
                gender_output = predictions[1]
                
                print(f"      Age output: {age_output[0]}")
                print(f"      Gender output: {gender_output[0]}")
                
                # Test gender interpretations
                if len(gender_output[0]) == 2:
                    probs = gender_output[0]
                    print(f"      Interpretation A: [Female={probs[0]:.3f}, Male={probs[1]:.3f}] → {'Male' if np.argmax(probs) == 1 else 'Female'}")
                    print(f"      Interpretation B: [Male={probs[0]:.3f}, Female={probs[1]:.3f}] → {'Male' if np.argmax(probs) == 0 else 'Female'}")
                elif len(gender_output[0]) == 1:
                    value = gender_output[0][0]
                    print(f"      Interpretation A: {value:.3f} → {'Male' if value > 0.5 else 'Female'} (0=Female, 1=Male)")
                    print(f"      Interpretation B: {value:.3f} → {'Female' if value > 0.5 else 'Male'} (0=Male, 1=Female)")
            
            # Strategy 2: Single output with multiple values
            elif hasattr(predictions, 'shape') and len(predictions.shape) == 2:
                print("\n   Strategy 2: Single output with multiple values")
                output = predictions[0]
                print(f"      Full output: {output}")
                
                if len(output) >= 2:
                    print(f"      Assuming [age, gender]: age={output[0]:.3f}, gender={output[1]:.3f}")
                    print(f"      Gender interpretation A: {'Male' if output[1] > 0.5 else 'Female'}")
                    print(f"      Gender interpretation B: {'Female' if output[1] > 0.5 else 'Male'}")
            
            print("\n   💡 RECOMMENDATIONS:")
            print("   1. Check your training data labels (0=Female, 1=Male or vice versa)")
            print("   2. Verify the model architecture matches your training setup")
            print("   3. Test with known images to validate the correct interpretation")
            print("   4. Update the enhanced_app.py with the correct gender mapping")
            
    except Exception as e:
        print(f"   ❌ Error in interpretation testing: {str(e)}")

def create_gender_fix_recommendations():
    """Create recommendations for fixing gender predictions"""
    
    print("\n" + "=" * 60)
    print("GENDER FIX RECOMMENDATIONS")
    print("=" * 60)
    
    print("""
🔧 COMMON GENDER PREDICTION FIXES:

1. LABEL MAPPING ISSUE (Most Common):
   Problem: Model outputs are correct but labels are swapped
   Fix: In enhanced_app.py, line ~335, change:
   
   # If currently using:
   gender_label = "Male" if np.argmax(gender_probs) == 1 else "Female"
   
   # Try this instead:
   gender_label = "Female" if np.argmax(gender_probs) == 1 else "Male"

2. BINARY OUTPUT INTERPRETATION:
   Problem: Single output value interpreted incorrectly
   Fix: In enhanced_app.py, line ~355, change:
   
   # If currently using:
   gender_label = "Male" if gender_confidence > 0.5 else "Female"
   
   # Try this instead:
   gender_label = "Female" if gender_confidence > 0.5 else "Male"

3. PREPROCESSING ISSUE:
   Problem: Face preprocessing doesn't match training
   Fix: Try different normalization strategies in preprocess_face()

4. MODEL OUTPUT FORMAT:
   Problem: Wrong output is being used for gender
   Fix: Check if gender is in a different output index

📝 TESTING STEPS:
1. Run: python debug_gender.py
2. Note the output interpretations
3. Test with known male/female images
4. Update enhanced_app.py accordingly
5. Verify accuracy improves
""")

if __name__ == "__main__":
    model_path = "age_gender_model3 .keras"  # Note: space in filename
    
    print("🔍 Starting gender prediction analysis...")
    analyze_gender_predictions(model_path)
    create_gender_fix_recommendations()
    
    print("\n✅ Gender analysis complete!")
    print("\n🎯 Next steps:")
    print("1. Review the output above")
    print("2. Test the recommended fixes in enhanced_app.py")
    print("3. Validate with known male/female images")
    print("4. Update the gender mapping based on results")
