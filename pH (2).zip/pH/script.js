// Pehchan AI - Frontend JavaScript
// DRDO PXE - Real-time Age & Gender Prediction System

class PehchanAI {
    constructor() {
        this.video = document.getElementById('videoElement');
        this.canvas = document.getElementById('canvasElement');
        this.ctx = this.canvas.getContext('2d');
        this.overlayCanvas = document.getElementById('overlayCanvas');
        this.overlayCtx = this.overlayCanvas.getContext('2d');
        this.stream = null;
        this.isProcessing = false;
        this.processingInterval = null;
        this.frameCount = 0;
        this.startTime = Date.now();

        // Age group definitions with emojis
        this.ageGroups = {
            child: { min: 3, max: 12, emoji: '🧒', label: 'Child' },
            teenager: { min: 13, max: 19, emoji: '🧑‍🎓', label: 'Teenager' },
            youngAdult: { min: 20, max: 29, emoji: '👨‍💼', label: 'Young Adult' },
            adult: { min: 30, max: 44, emoji: '🧔', label: 'Adult' },
            middleAged: { min: 45, max: 59, emoji: '👴', label: 'Middle-aged' },
            senior: { min: 60, max: 100, emoji: '👵', label: 'Senior' }
        };
        
        // UI Elements
        this.startBtn = document.getElementById('startCameraBtn');
        this.stopBtn = document.getElementById('stopCameraBtn');
        this.videoPlaceholder = document.getElementById('videoPlaceholder');
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.errorModal = document.getElementById('errorModal');
        
        // Prediction Elements
        this.ageValue = document.getElementById('ageValue');
        this.genderValue = document.getElementById('genderValue');
        this.confidenceValue = document.getElementById('confidenceValue');
        this.predictionStatus = document.getElementById('predictionStatus');
        this.modelStatus = document.getElementById('modelStatus');
        this.processingRate = document.getElementById('processingRate');
        this.lastUpdate = document.getElementById('lastUpdate');

        // Enhanced prediction elements
        this.stabilityValue = document.getElementById('stabilityValue');
        this.sampleCount = document.getElementById('sampleCount');
        this.facesDetected = document.getElementById('facesDetected');
        this.multipleFaces = document.getElementById('multipleFaces');
        this.facesList = document.getElementById('facesList');
        
        this.initializeEventListeners();
        this.checkBackendStatus();
        this.initializeNeuralParticles();
    }

    getAgeGroup(age) {
        for (const [key, group] of Object.entries(this.ageGroups)) {
            if (age >= group.min && age <= group.max) {
                return group;
            }
        }
        // Default fallback
        return this.ageGroups.adult;
    }

    initializeNeuralParticles() {
        const particlesContainer = document.getElementById('neuralParticles');
        const particleCount = 20;

        for (let i = 0; i < particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 15 + 's';
            particle.style.animationDuration = (15 + Math.random() * 10) + 's';
            particlesContainer.appendChild(particle);
        }
    }

    initializeEventListeners() {
        this.startBtn.addEventListener('click', () => this.startCamera());
        this.stopBtn.addEventListener('click', () => this.stopCamera());
        
        // Handle page visibility changes
        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.isProcessing) {
                this.pauseProcessing();
            } else if (!document.hidden && this.stream) {
                this.resumeProcessing();
            }
        });
    }

    async checkBackendStatus() {
        try {
            this.showLoading('Checking system status...');
            const response = await fetch('/api/status');
            const data = await response.json();
            
            if (data.status === 'ready') {
                this.modelStatus.textContent = 'Ready';
                this.modelStatus.style.color = '#00ff00';
                this.updatePredictionStatus('System ready for analysis');
            } else {
                throw new Error('Backend not ready');
            }
        } catch (error) {
            console.error('Backend status check failed:', error);
            this.modelStatus.textContent = 'Offline';
            this.modelStatus.style.color = '#ff4444';
            this.updatePredictionStatus('Backend connection failed');
        } finally {
            this.hideLoading();
        }
    }

    async startCamera() {
        try {
            this.showLoading('Accessing camera...');
            
            // Request camera access
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: 'user'
                },
                audio: false
            });

            // Set up video stream
            this.video.srcObject = this.stream;
            this.video.style.display = 'block';
            this.videoPlaceholder.style.display = 'none';
            
            // Wait for video to load
            await new Promise((resolve) => {
                this.video.onloadedmetadata = () => {
                    this.canvas.width = this.video.videoWidth;
                    this.canvas.height = this.video.videoHeight;

                    // Set overlay canvas size to match video display
                    const videoRect = this.video.getBoundingClientRect();
                    this.overlayCanvas.width = videoRect.width;
                    this.overlayCanvas.height = videoRect.height;

                    resolve();
                };
            });

            // Update UI
            this.startBtn.style.display = 'none';
            this.stopBtn.style.display = 'inline-flex';
            this.updatePredictionStatus('Camera active - Starting analysis...');
            
            // Start processing
            this.startProcessing();
            
        } catch (error) {
            console.error('Camera access failed:', error);
            this.showError('Camera access denied or not available. Please check permissions.');
            this.updatePredictionStatus('Camera access failed');
        } finally {
            this.hideLoading();
        }
    }

    stopCamera() {
        // Stop processing
        this.stopProcessing();
        
        // Stop video stream
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        // Reset UI
        this.video.style.display = 'none';
        this.videoPlaceholder.style.display = 'block';
        this.startBtn.style.display = 'inline-flex';
        this.stopBtn.style.display = 'none';
        
        // Reset predictions
        this.resetPredictions();
        this.updatePredictionStatus('Camera stopped');
        this.processingRate.textContent = '-- FPS';
    }

    startProcessing() {
        this.isProcessing = true;
        this.frameCount = 0;
        this.startTime = Date.now();
        
        // Process frames every 2 seconds as requested
        this.processingInterval = setInterval(() => {
            if (this.isProcessing && this.video.readyState === 4) {
                this.captureAndAnalyze();
            }
        }, 2000);
    }

    stopProcessing() {
        this.isProcessing = false;
        if (this.processingInterval) {
            clearInterval(this.processingInterval);
            this.processingInterval = null;
        }
    }

    pauseProcessing() {
        this.isProcessing = false;
    }

    resumeProcessing() {
        this.isProcessing = true;
    }

    async captureAndAnalyze() {
        try {
            // Capture frame from video
            this.ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
            const imageData = this.canvas.toDataURL('image/jpeg', 0.8);
            
            // Send to backend for analysis
            const response = await fetch('/api/predict', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    image: imageData.split(',')[1] // Remove data:image/jpeg;base64, prefix
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            this.updatePredictions(result);
            this.updateFrameRate();
            
        } catch (error) {
            console.error('Analysis failed:', error);
            this.updatePredictionStatus('Analysis error - retrying...');
        }
    }

    updatePredictions(result) {
        // NO video overlays - predictions only in side panel

        // Handle enhanced backend response with multiple faces
        if (result.faces_detected !== undefined) {
            this.handleEnhancedPredictions(result);
        } else {
            // Fallback for simple predictions (test server)
            this.handleSimplePredictions(result);
        }

        this.updatePredictionStatus(`Analysis active - ${result.faces_detected || 1} face(s) detected`);
        this.lastUpdate.textContent = new Date().toLocaleTimeString();
    }

    handleEnhancedPredictions(result) {
        // Update faces detected count
        this.facesDetected.textContent = result.faces_detected;

        if (result.faces_detected === 0) {
            this.resetPredictionDisplay();
            this.updatePredictionStatus('No faces detected');
            this.multipleFaces.style.display = 'none';
            return;
        }

        // Use the first face's stable prediction for main display
        const firstFace = result.predictions[0];
        if (firstFace && firstFace.stable_prediction) {
            const stable = firstFace.stable_prediction;

            // Get age group emoji
            const ageGroupEmoji = this.getAgeGroupEmoji(stable.age_group);

            // Update main prediction display in side panel ONLY
            this.ageValue.textContent = `${ageGroupEmoji} ${stable.age_group}`;
            this.genderValue.textContent = stable.gender;
            this.confidenceValue.textContent = `${Math.round(stable.confidence * 100)}%`;

            // Update enhanced details
            this.stabilityValue.textContent = `${Math.round(stable.stability_score * 100)}%`;
            this.sampleCount.textContent = stable.sample_count;

            // Update status with stability info
            this.updatePredictionStatus(`Primary face: ${Math.round(stable.stability_score * 100)}% stable (${stable.sample_count} samples)`);

            // Show multiple faces if more than one
            this.updateMultipleFacesDisplay(result.predictions);
        }
    }

    handleSimplePredictions(result) {
        // Handle simple test server predictions - SIDE PANEL ONLY
        if (result.age !== undefined) {
            const ageGroup = this.getAgeGroup(result.age);
            this.ageValue.textContent = `${ageGroup.emoji} ${ageGroup.label} (${Math.round(result.age)})`;
        }

        if (result.gender !== undefined) {
            this.genderValue.textContent = result.gender;
        }

        if (result.confidence !== undefined) {
            this.confidenceValue.textContent = `${Math.round(result.confidence * 100)}%`;
        }

        // NO video overlays - predictions only in side panel
    }

    getAgeGroupEmoji(ageGroupName) {
        const emojiMap = {
            'Child': '🧒',
            'Teenager': '🧑‍🎓',
            'Young Adult': '👨‍💼',
            'Adult': '🧔',
            'Middle-aged': '👴',
            'Senior': '👵'
        };
        return emojiMap[ageGroupName] || '👤';
    }

    resetPredictionDisplay() {
        this.ageValue.textContent = '--';
        this.genderValue.textContent = '--';
        this.confidenceValue.textContent = '--';
        this.stabilityValue.textContent = '--';
        this.sampleCount.textContent = '--';
        this.facesDetected.textContent = '--';
    }

    updateMultipleFacesDisplay(predictions) {
        if (predictions.length <= 1) {
            this.multipleFaces.style.display = 'none';
            return;
        }

        this.multipleFaces.style.display = 'block';
        this.facesList.innerHTML = '';

        predictions.forEach((pred, index) => {
            if (pred.stable_prediction) {
                const stable = pred.stable_prediction;
                const emoji = this.getAgeGroupEmoji(stable.age_group);

                const faceItem = document.createElement('div');
                faceItem.className = 'face-item';

                faceItem.innerHTML = `
                    <div class="face-id">Face ${index + 1} (ID: ${pred.face_id})</div>
                    <div class="face-prediction">
                        ${emoji} ${stable.age_group} • ${stable.gender}<br>
                        Confidence: ${Math.round(stable.confidence * 100)}% •
                        Stability: ${Math.round(stable.stability_score * 100)}%<br>
                        Samples: ${stable.sample_count}
                    </div>
                `;

                this.facesList.appendChild(faceItem);
            }
        });
    }

    // All overlay drawing methods removed - predictions display only in side panel

    updateFrameRate() {
        this.frameCount++;
        const elapsed = (Date.now() - this.startTime) / 1000;
        const fps = (this.frameCount / elapsed).toFixed(1);
        this.processingRate.textContent = `${fps} FPS`;
    }

    resetPredictions() {
        this.ageValue.textContent = '--';
        this.genderValue.textContent = '--';
        this.confidenceValue.textContent = '--';
        this.lastUpdate.textContent = '--';
    }

    updatePredictionStatus(message) {
        this.predictionStatus.textContent = message;
    }

    showLoading(message = 'Loading...') {
        const loadingText = document.querySelector('.loading-text');
        if (loadingText) loadingText.textContent = message;
        this.loadingOverlay.classList.add('active');
    }

    hideLoading() {
        this.loadingOverlay.classList.remove('active');
    }

    showError(message) {
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.textContent = message;
        this.errorModal.classList.add('active');
    }
}

// Global function to close error modal
function closeErrorModal() {
    document.getElementById('errorModal').classList.remove('active');
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.pehchanAI = new PehchanAI();
});

// Handle page unload
window.addEventListener('beforeunload', () => {
    if (window.pehchanAI && window.pehchanAI.stream) {
        window.pehchanAI.stopCamera();
    }
});
