#!/usr/bin/env python3
"""
Quick Gender Fix for Pehchan AI
Run this script to quickly test and fix gender prediction accuracy
"""

import os

def quick_gender_test():
    """Quick test to identify gender prediction issues"""
    
    print("🔧 QUICK GENDER FIX TOOL")
    print("=" * 50)
    
    # Check if model exists
    model_path = "age_gender_model3 .keras"  # Note: space in filename
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        print("   Please ensure your .keras model is in the current directory")
        return
    
    print("✅ Model file found")
    
    # Check current configuration
    try:
        from gender_config import GENDER_INTERPRETATION
        print(f"📋 Current gender interpretation: {GENDER_INTERPRETATION}")
    except ImportError:
        print("📋 Gender config not found - will use default")
        GENDER_INTERPRETATION = "A"
    
    # Show quick fix options
    print("\n🎯 QUICK FIX OPTIONS:")
    print("=" * 50)
    
    print("""
OPTION 1: Test with your model (Recommended)
   Run: python test_gender_accuracy.py
   This will show you which interpretation is correct

OPTION 2: Try the opposite interpretation
   If gender predictions are wrong, try switching interpretations:
   
   Current: {current}
   Switch to: {switch}
   
   To switch:
   1. Edit gender_config.py
   2. Change GENDER_INTERPRETATION = "{current}" to "{switch}"
   3. Restart enhanced_app.py

OPTION 3: Manual testing
   1. Start the web interface
   2. Test with known male/female faces
   3. If results are wrong, switch interpretation

OPTION 4: Debug your model structure
   Run: python debug_gender.py
   This will analyze your model's output format in detail
""".format(
        current=GENDER_INTERPRETATION,
        switch="B" if GENDER_INTERPRETATION == "A" else "A"
    ))
    
    # Interactive fix
    print("\n🤖 INTERACTIVE FIX:")
    print("=" * 50)
    
    response = input("Do you want to switch the gender interpretation now? (y/n): ").lower().strip()
    
    if response == 'y':
        switch_gender_interpretation(GENDER_INTERPRETATION)
    else:
        print("No changes made. You can manually edit gender_config.py later.")
    
    # Show next steps
    print("\n📋 NEXT STEPS:")
    print("=" * 50)
    print("""
1. Restart your server:
   python enhanced_app.py

2. Test the web interface:
   http://localhost:5000

3. Check gender predictions with real faces

4. If still wrong, run this script again to switch back

5. For detailed analysis:
   python debug_gender.py
   python test_gender_accuracy.py
""")

def switch_gender_interpretation(current):
    """Switch the gender interpretation in the config file"""
    
    try:
        new_interpretation = "B" if current == "A" else "A"
        
        # Read current config
        with open("gender_config.py", "r") as f:
            content = f.read()
        
        # Replace the interpretation
        old_line = f'GENDER_INTERPRETATION = "{current}"'
        new_line = f'GENDER_INTERPRETATION = "{new_interpretation}"'
        
        if old_line in content:
            new_content = content.replace(old_line, new_line)
            
            # Write back
            with open("gender_config.py", "w") as f:
                f.write(new_content)
            
            print(f"✅ Switched gender interpretation from {current} to {new_interpretation}")
            print("   Please restart enhanced_app.py for changes to take effect")
        else:
            print(f"❌ Could not find line to replace: {old_line}")
            print("   Please manually edit gender_config.py")
            
    except Exception as e:
        print(f"❌ Error switching interpretation: {str(e)}")
        print("   Please manually edit gender_config.py")

def show_common_fixes():
    """Show common gender prediction fixes"""
    
    print("\n🔧 COMMON GENDER PREDICTION ISSUES:")
    print("=" * 50)
    
    print("""
ISSUE 1: All predictions show same gender
   CAUSE: Model output interpretation is wrong
   FIX: Switch gender interpretation (A ↔ B)

ISSUE 2: Predictions are random/inconsistent
   CAUSE: Model preprocessing doesn't match training
   FIX: Check image normalization in enhanced_app.py

ISSUE 3: Model loads but gives errors
   CAUSE: Model format not recognized
   FIX: Run debug_gender.py to analyze model structure

ISSUE 4: Confidence is always low
   CAUSE: Wrong output being used for gender
   FIX: Check if gender is in different model output

ISSUE 5: Predictions opposite of expected
   CAUSE: Label mapping is inverted
   FIX: Switch interpretation A ↔ B
""")

if __name__ == "__main__":
    quick_gender_test()
    show_common_fixes()
    
    print("\n🎯 SUMMARY:")
    print("If gender predictions are wrong, the most common fix is:")
    print("1. Switch gender interpretation in gender_config.py")
    print("2. Restart enhanced_app.py")
    print("3. Test again")
    
    print("\nFor detailed debugging, run:")
    print("- python debug_gender.py (analyze model)")
    print("- python test_gender_accuracy.py (test with data)")
    print("- python quick_gender_fix.py (this script)")
