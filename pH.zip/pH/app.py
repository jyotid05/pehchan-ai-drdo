#!/usr/bin/env python3
"""
Pehchan AI - Flask Backend
DRDO PXE - Real-time Age & Gender Prediction System

This Flask application serves the AI model for real-time age and gender prediction
from webcam images captured by the frontend.
"""

import os
import io
import base64
import logging
from datetime import datetime
import numpy as np
from PIL import Image
import cv2
import tensorflow as tf
from flask import Flask, request, jsonify, render_template_string, send_from_directory
from flask_cors import CORS

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

class PehchanAIModel:
    """
    Wrapper class for the age and gender prediction model
    """
    
    def __init__(self, model_path):
        self.model_path = model_path
        self.model = None
        self.is_loaded = False
        self.load_model()
    
    def load_model(self):
        """Load the Keras model"""
        try:
            logger.info(f"Loading model from {self.model_path}")
            self.model = tf.keras.models.load_model(self.model_path)
            self.is_loaded = True
            logger.info("Model loaded successfully")
            
            # Print model summary for debugging
            logger.info("Model architecture:")
            self.model.summary()
            
        except Exception as e:
            logger.error(f"Failed to load model: {str(e)}")
            self.is_loaded = False
            raise
    
    def detect_faces(self, image):
        """
        Detect faces in the image using OpenCV

        Args:
            image: PIL Image object

        Returns:
            List of face bounding boxes [(x, y, w, h), ...]
        """
        try:
            # Convert PIL to OpenCV format
            img_array = np.array(image)
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)

            # Load face cascade classifier
            face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

            # Detect faces
            faces = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30)
            )

            return faces.tolist() if len(faces) > 0 else []

        except Exception as e:
            logger.error(f"Face detection failed: {str(e)}")
            return []

    def preprocess_image(self, image, bbox=None):
        """
        Preprocess the input image for model prediction

        Args:
            image: PIL Image object
            bbox: Optional bounding box (x, y, w, h) to crop face region

        Returns:
            Preprocessed numpy array ready for model input
        """
        try:
            # Convert PIL image to numpy array
            img_array = np.array(image)

            # If bbox provided, crop the face region
            if bbox:
                x, y, w, h = bbox
                img_array = img_array[y:y+h, x:x+w]

            # Convert RGB to BGR if needed (OpenCV format)
            if len(img_array.shape) == 3 and img_array.shape[2] == 3:
                img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)

            # Resize image to model input size (assuming 224x224, adjust as needed)
            img_resized = cv2.resize(img_array, (224, 224))

            # Normalize pixel values to [0, 1]
            img_normalized = img_resized.astype(np.float32) / 255.0

            # Add batch dimension
            img_batch = np.expand_dims(img_normalized, axis=0)

            return img_batch

        except Exception as e:
            logger.error(f"Image preprocessing failed: {str(e)}")
            raise
    
    def predict(self, image):
        """
        Make age and gender predictions on the input image with face detection

        Args:
            image: PIL Image object

        Returns:
            Dictionary containing age, gender, confidence predictions and face bounding boxes
        """
        if not self.is_loaded:
            raise RuntimeError("Model not loaded")

        try:
            # Detect faces first
            faces = self.detect_faces(image)

            if not faces:
                # No faces detected, use full image
                processed_image = self.preprocess_image(image)
                bbox = None
            else:
                # Use the largest face detected
                largest_face = max(faces, key=lambda f: f[2] * f[3])
                processed_image = self.preprocess_image(image, largest_face)
                bbox = largest_face

            # Make prediction
            predictions = self.model.predict(processed_image, verbose=0)
            
            # Parse predictions based on model output format
            # Note: Adjust this based on your specific model's output format
            if isinstance(predictions, list) and len(predictions) == 2:
                # Assuming model outputs [age, gender] as separate outputs
                age_pred = predictions[0][0][0]  # First output, first batch, first value
                gender_pred = predictions[1][0]  # Second output, first batch
                
                # Process gender prediction (assuming binary classification)
                gender_confidence = float(np.max(gender_pred))
                gender_label = "Male" if np.argmax(gender_pred) == 1 else "Female"
                
                # Process age prediction
                predicted_age = float(age_pred)
                
            else:
                # Single output model - adjust based on your model structure
                pred = predictions[0]
                if len(pred) >= 2:
                    predicted_age = float(pred[0])
                    gender_confidence = float(pred[1])
                    gender_label = "Male" if gender_confidence > 0.5 else "Female"
                else:
                    # Fallback for unknown model structure
                    predicted_age = 25.0
                    gender_confidence = 0.5
                    gender_label = "Unknown"
            
            # Ensure age is within reasonable bounds
            predicted_age = max(1, min(100, predicted_age))
            
            result = {
                'age': predicted_age,
                'gender': gender_label,
                'confidence': gender_confidence,
                'timestamp': datetime.now().isoformat(),
                'bbox': bbox if bbox else None,
                'faces_detected': len(faces) if faces else 0
            }
            
            logger.info(f"Prediction result: {result}")
            return result
            
        except Exception as e:
            logger.error(f"Prediction failed: {str(e)}")
            raise

# Initialize the model
MODEL_PATH = "age_gender_model3.keras"
try:
    ai_model = PehchanAIModel(MODEL_PATH)
except Exception as e:
    logger.error(f"Failed to initialize model: {str(e)}")
    ai_model = None

@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    """Serve static files (CSS, JS)"""
    return send_from_directory('.', filename)

@app.route('/api/status')
def get_status():
    """
    Get the current status of the AI system
    
    Returns:
        JSON response with system status
    """
    try:
        status = {
            'status': 'ready' if ai_model and ai_model.is_loaded else 'error',
            'model_loaded': ai_model.is_loaded if ai_model else False,
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        }
        return jsonify(status)
    except Exception as e:
        logger.error(f"Status check failed: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/predict', methods=['POST'])
def predict():
    """
    Predict age and gender from uploaded image
    
    Expects:
        JSON with base64 encoded image data
        
    Returns:
        JSON with age, gender, and confidence predictions
    """
    try:
        if not ai_model or not ai_model.is_loaded:
            return jsonify({'error': 'Model not available'}), 503
        
        # Get JSON data
        data = request.get_json()
        if not data or 'image' not in data:
            return jsonify({'error': 'No image data provided'}), 400
        
        # Decode base64 image
        try:
            image_data = base64.b64decode(data['image'])
            image = Image.open(io.BytesIO(image_data))
            
            # Convert to RGB if needed
            if image.mode != 'RGB':
                image = image.convert('RGB')
                
        except Exception as e:
            logger.error(f"Image decoding failed: {str(e)}")
            return jsonify({'error': 'Invalid image data'}), 400
        
        # Make prediction
        try:
            result = ai_model.predict(image)
            return jsonify(result)
            
        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            return jsonify({'error': 'Prediction failed'}), 500
            
    except Exception as e:
        logger.error(f"Request processing failed: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Check if model file exists
    if not os.path.exists(MODEL_PATH):
        logger.error(f"Model file not found: {MODEL_PATH}")
        logger.info("Please ensure the model file is in the same directory as app.py")
    
    # Start the Flask development server
    logger.info("Starting Pehchan AI Flask server...")
    logger.info("Access the application at: http://localhost:5000")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )
