# Enhanced Pehchan AI - DRDO PXE
## Real-time Age & Gender Prediction with Prediction Smoothing

A professional AI system that deploys your trained .keras model with advanced prediction smoothing using a 20-second rolling buffer to eliminate fluctuating predictions.

## 🎯 **Key Features**

### 🧠 **Model Integration**
- **Direct .keras model loading** - Uses your trained model without modification
- **Face detection** - OpenCV-based face detection and cropping
- **Age group categorization** - Maps numerical age to meaningful categories
- **Gender classification** - Male/Female prediction with confidence scores

### 📊 **Prediction Smoothing**
- **20-second rolling buffer** - Stores timestamped predictions for each detected face
- **Majority voting** - Returns most frequent prediction in the buffer
- **Stability scoring** - Indicates prediction confidence based on consistency
- **Face tracking** - Maintains separate buffers for multiple faces

### 🎨 **Enhanced Interface**
- **Real-time overlays** - Bounding boxes with stability indicators
- **Age group emojis** - Visual categorization with emoji indicators
- **Stability visualization** - Color-coded boxes based on prediction stability
- **Multiple face support** - Handles multiple faces simultaneously

## 🏗️ **System Architecture**

### Backend Components

#### 1. **Enhanced Flask Backend** (`enhanced_app.py`)
```python
class EnhancedPehchanAI:
    - Model loading and inference
    - Face detection with OpenCV
    - Prediction smoothing with rolling buffer
    - Age group mapping
    - Multi-face handling
```

#### 2. **Prediction Buffer** (`PredictionBuffer`)
```python
class PredictionBuffer:
    - 20-second timestamp-based storage
    - Automatic cleanup of old predictions
    - Majority voting algorithm
    - Stability score calculation
```

#### 3. **Face Detection Pipeline**
```python
detect_faces() -> preprocess_face() -> predict_single_face() -> add_to_buffer() -> get_stable_prediction()
```

### Frontend Components

#### 1. **Enhanced JavaScript** (`script.js`)
- Handles multiple face predictions
- Draws stability-colored bounding boxes
- Displays age group emojis
- Shows sample count and stability scores

#### 2. **Visual Overlays**
- Color-coded bounding boxes (green = stable, yellow = moderate, orange = unstable)
- Age group labels with emojis
- Gender and confidence display
- Stability percentage indicators

## 🔧 **Age Group Mapping**

The system maps numerical age predictions to these categories:

| Age Range | Category | Emoji |
|-----------|----------|-------|
| 3-12 | Child | 🧒 |
| 13-19 | Teenager | 🧑‍🎓 |
| 20-29 | Young Adult | 👨‍💼 |
| 30-44 | Adult | 🧔 |
| 45-59 | Middle-aged | 👴 |
| 60+ | Senior | 👵 |

## 📈 **Prediction Smoothing Algorithm**

### 1. **Buffer Management**
```python
# For each face detection:
1. Generate unique face_id based on position
2. Get raw prediction from model
3. Add (timestamp, prediction) to face buffer
4. Remove predictions older than 20 seconds
5. Calculate majority vote for stable result
```

### 2. **Majority Voting**
```python
# Stability calculation:
age_groups = [pred['age_group'] for _, pred in recent_predictions]
most_common_age = Counter(age_groups).most_common(1)[0][0]
stability_score = max(Counter(age_groups).values()) / len(age_groups)
```

### 3. **Stability Scoring**
- **Green (>70%)**: Highly stable predictions
- **Yellow (50-70%)**: Moderately stable predictions  
- **Orange (<50%)**: Unstable predictions

## 🚀 **Installation & Setup**

### 1. **Install Dependencies**
```bash
pip install -r requirements.txt
```

### 2. **Place Your Model**
```bash
# Copy your trained model to the project directory
cp your_model.keras age_gender_model3.keras
```

### 3. **Start Enhanced Backend**
```bash
# For production with your real model
python enhanced_app.py

# For testing with mock predictions
python enhanced_test_server.py
```

### 4. **Access Interface**
```bash
# Production: http://localhost:5000
# Testing: http://localhost:8001
```

## 📊 **API Endpoints**

### **POST /api/predict**
Enhanced prediction with face detection and smoothing.

**Request:**
```json
{
  "image": "base64_encoded_image_data"
}
```

**Response:**
```json
{
  "faces_detected": 2,
  "predictions": [
    {
      "face_id": "abc12345",
      "bbox": [100, 50, 200, 250],
      "stable_prediction": {
        "age_group": "Young Adult",
        "gender": "Male",
        "confidence": 0.87,
        "sample_count": 15,
        "stability_score": 0.93
      },
      "raw_prediction": {
        "age_group": "Adult",
        "gender": "Male", 
        "confidence": 0.82
      }
    }
  ]
}
```

### **GET /api/buffer/status**
Debug endpoint to view buffer status.

**Response:**
```json
{
  "active_faces": 2,
  "buffer_details": {
    "face_abc12345": {
      "prediction_count": 15,
      "oldest_prediction": "2024-01-01T12:00:00",
      "newest_prediction": "2024-01-01T12:00:20"
    }
  },
  "buffer_duration": 20
}
```

## 🔍 **Model Requirements**

Your .keras model should:

1. **Accept input shape**: `(batch_size, 224, 224, 3)` (adjust in code if different)
2. **Output format**: Either:
   - Two outputs: `[age_prediction, gender_prediction]`
   - Single output: `[age, gender_confidence]`
3. **Age output**: Numerical age (will be mapped to categories)
4. **Gender output**: Binary classification or confidence score

## 🎛️ **Configuration Options**

### **Buffer Duration**
```python
# Adjust buffer duration (default: 20 seconds)
prediction_buffer = PredictionBuffer(buffer_duration=30)
```

### **Face Detection Parameters**
```python
# Adjust face detection sensitivity
faces = face_cascade.detectMultiScale(
    gray,
    scaleFactor=1.1,      # Adjust for detection sensitivity
    minNeighbors=5,       # Adjust for false positive reduction
    minSize=(50, 50),     # Minimum face size
    maxSize=(300, 300)    # Maximum face size
)
```

### **Stability Thresholds**
```python
# Adjust stability color coding
stability_color = stable.stability_score > 0.7 ? '#00ff00' :   # Green
                 stable.stability_score > 0.5 ? '#ffff00' :   # Yellow
                 '#ff8800'                                    # Orange
```

## 🧪 **Testing**

### **Enhanced Test Server**
The `enhanced_test_server.py` simulates the complete system:
- Mock face detection (1-2 faces)
- Simulated model fluctuations
- Real prediction smoothing
- Buffer management testing

### **Buffer Status Monitoring**
Visit `/api/buffer/status` to monitor:
- Active face count
- Prediction counts per face
- Buffer timestamps
- System performance

## 🔧 **Troubleshooting**

### **Model Loading Issues**
- Ensure model file exists: `age_gender_model3.keras`
- Check model input/output format compatibility
- Verify TensorFlow version compatibility

### **Face Detection Issues**
- Adjust `scaleFactor` and `minNeighbors` parameters
- Ensure adequate lighting in webcam feed
- Check OpenCV installation

### **Prediction Instability**
- Increase buffer duration for more smoothing
- Adjust stability thresholds
- Check model prediction quality

## 📈 **Performance Optimization**

1. **Model Optimization**: Use TensorFlow Lite for faster inference
2. **Face Detection**: Adjust parameters for speed vs accuracy
3. **Buffer Management**: Tune buffer duration based on use case
4. **Memory Usage**: Monitor buffer size for long-running sessions

---

**Enhanced Pehchan AI v2.0** - Professional AI deployment with prediction smoothing  
© 2024 Defence Research and Development Organisation (DRDO) - PXE
