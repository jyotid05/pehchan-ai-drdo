#!/usr/bin/env python3
"""
Enhanced Pehchan AI - Flask Backend with Prediction Smoothing
DRDO PXE - Real-time Age & Gender Prediction System

This Flask application serves the AI model with 20-second rolling buffer
for stable predictions and comprehensive face detection.
"""

import os
import io
import base64
import logging
import hashlib
from datetime import datetime, timedelta
from collections import defaultdict, Counter
import numpy as np
from PIL import Image
import cv2
import tensorflow as tf
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Configure logging first
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import gender configuration
try:
    from gender_config import (
        get_gender_from_binary_classification,
        get_gender_from_single_value,
        get_gender_from_multi_class,
        GENDER_INTERPRETATION
    )
    logger.info(f"Using gender interpretation: {GENDER_INTERPRETATION}")
    GENDER_CONFIG_AVAILABLE = True
except ImportError:
    logger.warning("Gender config not found, using default interpretation")
    GENDER_INTERPRETATION = "A"
    GENDER_CONFIG_AVAILABLE = False

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend communication

class PredictionBuffer:
    """
    Manages rolling 20-second buffer for prediction smoothing
    """
    
    def __init__(self, buffer_duration=20):
        self.buffer_duration = buffer_duration  # seconds
        self.predictions = defaultdict(list)  # face_id -> [(timestamp, prediction), ...]
        
    def add_prediction(self, face_id, prediction):
        """Add a new prediction for a face"""
        timestamp = datetime.now()
        self.predictions[face_id].append((timestamp, prediction))
        self._cleanup_old_predictions(face_id)
        
    def get_stable_prediction(self, face_id):
        """Get the most frequent prediction in the last 20 seconds"""
        if face_id not in self.predictions or not self.predictions[face_id]:
            return None
            
        # Get recent predictions
        recent_predictions = self.predictions[face_id]
        
        if not recent_predictions:
            return None
            
        # Extract age groups and genders
        age_groups = [pred['age_group'] for _, pred in recent_predictions]
        genders = [pred['gender'] for _, pred in recent_predictions]
        
        # Find most frequent predictions
        most_common_age = Counter(age_groups).most_common(1)[0][0]
        most_common_gender = Counter(genders).most_common(1)[0][0]
        
        # Calculate average confidence
        confidences = [pred['confidence'] for _, pred in recent_predictions]
        avg_confidence = sum(confidences) / len(confidences)
        
        return {
            'age_group': most_common_age,
            'gender': most_common_gender,
            'confidence': avg_confidence,
            'sample_count': len(recent_predictions),
            'stability_score': max(Counter(age_groups).values()) / len(age_groups)
        }
        
    def _cleanup_old_predictions(self, face_id):
        """Remove predictions older than buffer_duration"""
        cutoff_time = datetime.now() - timedelta(seconds=self.buffer_duration)
        self.predictions[face_id] = [
            (timestamp, pred) for timestamp, pred in self.predictions[face_id]
            if timestamp > cutoff_time
        ]

class EnhancedPehchanAI:
    """
    Enhanced AI model wrapper with face detection and prediction smoothing
    """
    
    def __init__(self, model_path):
        self.model_path = model_path
        self.model = None
        self.is_loaded = False
        self.face_cascade = None
        self.prediction_buffer = PredictionBuffer()
        
        # Age group definitions with inclusive boundaries
        self.age_groups = {
            'Child': (0, 12),        # 0-12 years
            'Teenager': (13, 19),    # 13-19 years
            'Young Adult': (20, 29), # 20-29 years
            'Adult': (30, 44),       # 30-44 years
            'Middle-aged': (45, 59), # 45-59 years
            'Senior': (60, 120)      # 60+ years
        }
        
        self.load_model()
        self.load_face_detector()
    
    def load_model(self):
        """Load the Keras model with detailed debugging"""
        try:
            logger.info(f"Loading model from {self.model_path}")
            self.model = tf.keras.models.load_model(self.model_path)
            self.is_loaded = True
            logger.info("Model loaded successfully")

            # Detailed model information for debugging
            logger.info("=== MODEL DEBUGGING INFO ===")
            logger.info(f"Model input shape: {self.model.input_shape}")
            logger.info(f"Model output shape: {self.model.output_shape}")
            logger.info(f"Number of layers: {len(self.model.layers)}")

            # Check if model has multiple outputs
            if isinstance(self.model.output_shape, list):
                logger.info(f"Multiple outputs detected: {len(self.model.output_shape)} outputs")
                for i, shape in enumerate(self.model.output_shape):
                    logger.info(f"Output {i}: {shape}")
            else:
                logger.info(f"Single output: {self.model.output_shape}")

            # Print model summary
            logger.info("Model architecture:")
            self.model.summary()
            logger.info("=== END MODEL DEBUG INFO ===")

        except Exception as e:
            logger.error(f"Failed to load model: {str(e)}")
            self.is_loaded = False
            raise
    
    def load_face_detector(self):
        """Load OpenCV face cascade classifier"""
        try:
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            self.face_cascade = cv2.CascadeClassifier(cascade_path)
            logger.info("Face detector loaded successfully")
        except Exception as e:
            logger.error(f"Failed to load face detector: {str(e)}")
            raise
    
    def detect_faces(self, image):
        """
        Detect faces in the image using OpenCV
        
        Args:
            image: PIL Image object
            
        Returns:
            List of face bounding boxes [(x, y, w, h), ...]
        """
        try:
            # Convert PIL to OpenCV format
            img_array = np.array(image)
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            
            # Detect faces with optimized parameters
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(50, 50),
                maxSize=(300, 300)
            )
            
            return faces.tolist() if len(faces) > 0 else []
            
        except Exception as e:
            logger.error(f"Face detection failed: {str(e)}")
            return []
    
    def generate_face_id(self, bbox, image_shape):
        """Generate a unique ID for a face based on position and size"""
        x, y, w, h = bbox
        img_h, img_w = image_shape[:2]
        
        # Normalize coordinates
        norm_x = x / img_w
        norm_y = y / img_h
        norm_w = w / img_w
        norm_h = h / img_h
        
        # Create hash from normalized coordinates (rounded for stability)
        coord_str = f"{norm_x:.2f}_{norm_y:.2f}_{norm_w:.2f}_{norm_h:.2f}"
        return hashlib.md5(coord_str.encode()).hexdigest()[:8]
    
    def preprocess_face(self, image, bbox):
        """
        Enhanced preprocessing for accurate model input

        Args:
            image: PIL Image object
            bbox: Face bounding box (x, y, w, h)

        Returns:
            Preprocessed numpy array ready for model input
        """
        try:
            # Convert to numpy array
            img_array = np.array(image)
            logger.debug(f"Original image shape: {img_array.shape}")

            # Extract face region with padding
            x, y, w, h = bbox
            padding = int(0.15 * min(w, h))  # 15% padding for better context
            x1 = max(0, x - padding)
            y1 = max(0, y - padding)
            x2 = min(img_array.shape[1], x + w + padding)
            y2 = min(img_array.shape[0], y + h + padding)

            face_img = img_array[y1:y2, x1:x2]
            logger.debug(f"Extracted face shape: {face_img.shape}")

            # Get model input size from the loaded model
            if hasattr(self.model, 'input_shape') and self.model.input_shape:
                if isinstance(self.model.input_shape, list):
                    input_shape = self.model.input_shape[0]  # First input if multiple
                else:
                    input_shape = self.model.input_shape

                # Extract height and width (assuming format: (batch, height, width, channels))
                if len(input_shape) >= 3:
                    target_height = input_shape[1] if input_shape[1] is not None else 64
                    target_width = input_shape[2] if input_shape[2] is not None else 64
                else:
                    target_height, target_width = 64, 64
            else:
                target_height, target_width = 64, 64  # Your model uses 64x64

            logger.debug(f"Target size: {target_height}x{target_width}")

            # Resize to model input size
            face_resized = cv2.resize(face_img, (target_width, target_height))
            logger.debug(f"Resized face shape: {face_resized.shape}")

            # Convert to float32 and normalize
            face_float = face_resized.astype(np.float32)

            # Try different normalization strategies based on common training practices
            # Strategy 1: [0, 1] normalization (most common)
            face_normalized = face_float / 255.0

            # Strategy 2: [-1, 1] normalization (uncomment if your model uses this)
            # face_normalized = (face_float / 127.5) - 1.0

            # Strategy 3: ImageNet normalization (uncomment if your model uses this)
            # mean = np.array([0.485, 0.456, 0.406])
            # std = np.array([0.229, 0.224, 0.225])
            # face_normalized = (face_float / 255.0 - mean) / std

            logger.debug(f"Normalized range: [{face_normalized.min():.3f}, {face_normalized.max():.3f}]")

            # Add batch dimension
            face_batch = np.expand_dims(face_normalized, axis=0)
            logger.debug(f"Final input shape: {face_batch.shape}")

            return face_batch

        except Exception as e:
            logger.error(f"Face preprocessing failed: {str(e)}")
            raise
    
    def map_age_to_group(self, age):
        """Map numerical age to age group with proper boundary handling"""
        # Ensure age is within reasonable bounds
        age = max(0, min(120, age))

        # Check each age group with inclusive boundaries
        for group_name, (min_age, max_age) in self.age_groups.items():
            if min_age <= age <= max_age:
                return group_name

        # Fallback for edge cases
        if age < 0:
            return 'Child'
        elif age > 120:
            return 'Senior'
        else:
            return 'Adult'  # Default fallback
    
    def predict_single_face(self, face_data):
        """
        Enhanced prediction with detailed debugging for accuracy

        Args:
            face_data: Preprocessed face image

        Returns:
            Dictionary with raw predictions
        """
        try:
            logger.debug(f"Making prediction on input shape: {face_data.shape}")

            # Make prediction
            predictions = self.model.predict(face_data, verbose=0)

            logger.debug(f"Raw prediction output type: {type(predictions)}")
            logger.debug(f"Raw prediction shape: {predictions.shape if hasattr(predictions, 'shape') else 'No shape'}")

            # Enhanced prediction parsing with multiple strategies
            age_pred = None
            gender_label = None
            gender_confidence = None

            # Strategy 1: Multiple outputs [gender, age] - CORRECTED ORDER
            if isinstance(predictions, list) and len(predictions) == 2:
                logger.debug("Detected multiple outputs format")
                # IMPORTANT: Your model outputs [gender_output, age_output] in this order
                gender_output = predictions[0]  # First output is gender
                age_output = predictions[1]     # Second output is age

                logger.debug(f"Gender output shape: {gender_output.shape}, values: {gender_output}")
                logger.debug(f"Age output shape: {age_output.shape}, values: {age_output}")

                # Parse age (regression output)
                if age_output.size == 1:
                    age_pred = float(age_output[0])
                else:
                    age_pred = float(age_output[0][0])

                # Enhanced gender parsing with multiple interpretation strategies
                gender_label, gender_confidence = self.parse_gender_output(gender_output[0], "multiple_outputs")

            # Strategy 2: Single output with multiple values
            elif hasattr(predictions, 'shape') and len(predictions.shape) == 2:
                logger.debug("Detected single output format")
                logger.debug(f"Prediction values: {predictions[0]}")

                if predictions.shape[1] >= 2:
                    # Assuming [age, gender_confidence] format
                    age_pred = float(predictions[0][0])
                    gender_raw = predictions[0][1]

                    # Use enhanced gender parsing
                    gender_label, gender_confidence = self.parse_gender_output(
                        np.array([gender_raw]), "single_output_multi_value"
                    )
                elif predictions.shape[1] == 1:
                    # Only age prediction
                    age_pred = float(predictions[0][0])
                    gender_confidence = 0.5
                    gender_label = "Unknown"

            # Strategy 3: Age classification (age groups as classes)
            elif hasattr(predictions, 'shape') and predictions.shape[-1] > 10:
                logger.debug("Detected age classification format")
                # Assuming age groups as classes
                age_class = np.argmax(predictions[0])
                age_pred = self.age_class_to_numeric(age_class)
                gender_confidence = 0.5
                gender_label = "Unknown"

            # Fallback strategy
            else:
                logger.warning(f"Unknown prediction format: {predictions}")
                logger.warning("Using fallback values")
                age_pred = 30.0
                gender_confidence = 0.5
                gender_label = "Unknown"

            # Validate and bound predictions
            if age_pred is None:
                age_pred = 30.0
            age_pred = max(3, min(100, age_pred))

            if gender_confidence is None:
                gender_confidence = 0.5
            gender_confidence = max(0.0, min(1.0, gender_confidence))

            if gender_label is None:
                gender_label = "Unknown"

            # Map age to group
            age_group = self.map_age_to_group(age_pred)

            logger.debug(f"Final predictions - Age: {age_pred}, Group: {age_group}, Gender: {gender_label}, Confidence: {gender_confidence}")

            return {
                'raw_age': age_pred,
                'age_group': age_group,
                'gender': gender_label,
                'confidence': gender_confidence
            }

        except Exception as e:
            logger.error(f"Prediction failed: {str(e)}")
            raise

    def age_class_to_numeric(self, age_class):
        """Convert age class index to numeric age (if using classification)"""
        # Adjust this mapping based on your model's age classes
        age_ranges = [
            (0, 5), (5, 10), (10, 15), (15, 20), (20, 25), (25, 30),
            (30, 35), (35, 40), (40, 45), (45, 50), (50, 55), (55, 60),
            (60, 65), (65, 70), (70, 75), (75, 80), (80, 85), (85, 90), (90, 100)
        ]

        if 0 <= age_class < len(age_ranges):
            min_age, max_age = age_ranges[age_class]
            return (min_age + max_age) / 2
        else:
            return 30.0  # Default fallback

    def parse_gender_output(self, gender_output, context=""):
        """
        Enhanced gender parsing with multiple interpretation strategies

        Args:
            gender_output: Raw gender output from model
            context: Context for debugging

        Returns:
            Tuple of (gender_label, confidence)
        """
        try:
            logger.debug(f"Parsing gender output in context '{context}': {gender_output}")

            # Strategy 1: Binary classification with 2 outputs [prob_class0, prob_class1]
            if len(gender_output.shape) == 1 and len(gender_output) == 2:
                logger.debug(f"Binary classification: {gender_output}")

                # Use configuration-based gender parsing
                if GENDER_CONFIG_AVAILABLE:
                    gender_label, confidence = get_gender_from_binary_classification(gender_output)
                    logger.debug(f"Using config interpretation {GENDER_INTERPRETATION}: {gender_label} (confidence: {confidence:.3f})")
                else:
                    # Fallback to default interpretation
                    predicted_class = np.argmax(gender_output)
                    confidence = float(np.max(gender_output))
                    gender_label = "Male" if predicted_class == 1 else "Female"  # Default: 0=Female, 1=Male
                    logger.debug(f"Using default interpretation: {gender_label}")

                return gender_label, confidence

            # Strategy 2: Single sigmoid output (0-1 range)
            elif len(gender_output.shape) == 1 and len(gender_output) == 1:
                value = float(gender_output[0])
                logger.debug(f"Single sigmoid: value={value}")

                # Use configuration-based gender parsing
                if GENDER_CONFIG_AVAILABLE:
                    gender_label, confidence = get_gender_from_single_value(value)
                    logger.debug(f"Using config interpretation {GENDER_INTERPRETATION}: {gender_label} (confidence: {confidence:.3f})")
                else:
                    # Fallback to default interpretation
                    confidence = max(value, 1 - value)
                    gender_label = "Male" if value > 0.5 else "Female"  # Default: 0=Female, 1=Male
                    logger.debug(f"Using default interpretation: {gender_label}")

                return gender_label, confidence

            # Strategy 3: Scalar value
            elif len(gender_output.shape) == 0:
                value = float(gender_output)
                confidence = max(value, 1 - value)

                # Same logic as single sigmoid
                gender_label = "Male" if value > 0.5 else "Female"  # Change if inverted

                logger.debug(f"Scalar value: {value} → {gender_label}")
                return gender_label, confidence

            # Strategy 4: Multi-class output (unusual for gender)
            elif len(gender_output) > 2:
                logger.debug(f"Multi-class output: {gender_output}")

                # Use configuration-based gender parsing
                if GENDER_CONFIG_AVAILABLE:
                    gender_label, confidence = get_gender_from_multi_class(gender_output)
                    logger.debug(f"Using config interpretation {GENDER_INTERPRETATION}: {gender_label}")
                else:
                    # Fallback to default interpretation
                    predicted_class = np.argmax(gender_output)
                    confidence = float(np.max(gender_output))
                    if predicted_class == 0:
                        gender_label = "Female"
                    elif predicted_class == 1:
                        gender_label = "Male"
                    else:
                        gender_label = "Unknown"
                    logger.debug(f"Using default interpretation: {gender_label}")

                return gender_label, confidence

            else:
                logger.warning(f"Unknown gender output format: {gender_output}")
                return "Unknown", 0.5

        except Exception as e:
            logger.error(f"Error parsing gender output: {str(e)}")
            return "Unknown", 0.5

    def predict_with_smoothing(self, image):
        """
        Main prediction method with face detection and smoothing

        Args:
            image: PIL Image object

        Returns:
            Dictionary with stable predictions for all detected faces
        """
        if not self.is_loaded:
            raise RuntimeError("Model not loaded")

        try:
            # Detect faces
            faces = self.detect_faces(image)

            if not faces:
                return {
                    'faces_detected': 0,
                    'predictions': [],
                    'message': 'No faces detected'
                }

            results = []
            img_array = np.array(image)

            for face_bbox in faces:
                try:
                    # Generate face ID
                    face_id = self.generate_face_id(face_bbox, img_array.shape)

                    # Preprocess face
                    face_data = self.preprocess_face(image, face_bbox)

                    # Get raw prediction
                    raw_prediction = self.predict_single_face(face_data)

                    # Add to buffer
                    self.prediction_buffer.add_prediction(face_id, raw_prediction)

                    # Get stable prediction
                    stable_prediction = self.prediction_buffer.get_stable_prediction(face_id)

                    if stable_prediction:
                        result = {
                            'face_id': face_id,
                            'bbox': face_bbox,
                            'stable_prediction': stable_prediction,
                            'raw_prediction': raw_prediction,
                            'timestamp': datetime.now().isoformat()
                        }
                        results.append(result)

                except Exception as e:
                    logger.error(f"Error processing face {face_bbox}: {str(e)}")
                    continue

            return {
                'faces_detected': len(faces),
                'predictions': results,
                'timestamp': datetime.now().isoformat()
            }

        except Exception as e:
            logger.error(f"Prediction with smoothing failed: {str(e)}")
            raise

# Initialize the enhanced model
MODEL_PATH = "age_gender_model3 .keras"  # Note: space in filename
try:
    ai_model = EnhancedPehchanAI(MODEL_PATH)
    logger.info("Enhanced Pehchan AI model initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize enhanced model: {str(e)}")
    ai_model = None

@app.route('/')
def index():
    """Serve the main HTML page"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def static_files(filename):
    """Serve static files (CSS, JS)"""
    return send_from_directory('.', filename)

@app.route('/api/status')
def get_status():
    """
    Get the current status of the enhanced AI system

    Returns:
        JSON response with system status
    """
    try:
        status = {
            'status': 'ready' if ai_model and ai_model.is_loaded else 'error',
            'model_loaded': ai_model.is_loaded if ai_model else False,
            'face_detector_loaded': ai_model.face_cascade is not None if ai_model else False,
            'buffer_active': True if ai_model else False,
            'timestamp': datetime.now().isoformat(),
            'version': '2.0.0-enhanced'
        }
        return jsonify(status)
    except Exception as e:
        logger.error(f"Status check failed: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/predict', methods=['POST'])
def predict():
    """
    Enhanced prediction endpoint with face detection and smoothing

    Expects:
        JSON with base64 encoded image data

    Returns:
        JSON with stable predictions for all detected faces
    """
    try:
        if not ai_model or not ai_model.is_loaded:
            return jsonify({'error': 'Model not available'}), 503

        # Get JSON data
        data = request.get_json()
        if not data or 'image' not in data:
            return jsonify({'error': 'No image data provided'}), 400

        # Decode base64 image
        try:
            image_data = base64.b64decode(data['image'])
            image = Image.open(io.BytesIO(image_data))

            # Convert to RGB if needed
            if image.mode != 'RGB':
                image = image.convert('RGB')

        except Exception as e:
            logger.error(f"Image decoding failed: {str(e)}")
            return jsonify({'error': 'Invalid image data'}), 400

        # Make enhanced prediction with smoothing
        try:
            result = ai_model.predict_with_smoothing(image)
            return jsonify(result)

        except Exception as e:
            logger.error(f"Enhanced prediction error: {str(e)}")
            return jsonify({'error': 'Prediction failed'}), 500

    except Exception as e:
        logger.error(f"Request processing failed: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

@app.route('/api/buffer/status')
def get_buffer_status():
    """Get current buffer status for debugging"""
    try:
        if not ai_model:
            return jsonify({'error': 'Model not available'}), 503

        buffer_info = {}
        for face_id, predictions in ai_model.prediction_buffer.predictions.items():
            buffer_info[face_id] = {
                'prediction_count': len(predictions),
                'oldest_prediction': predictions[0][0].isoformat() if predictions else None,
                'newest_prediction': predictions[-1][0].isoformat() if predictions else None
            }

        return jsonify({
            'active_faces': len(buffer_info),
            'buffer_details': buffer_info,
            'buffer_duration': ai_model.prediction_buffer.buffer_duration
        })

    except Exception as e:
        logger.error(f"Buffer status check failed: {str(e)}")
        return jsonify({'error': 'Buffer status unavailable'}), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    # Check if model file exists
    if not os.path.exists(MODEL_PATH):
        logger.error(f"Model file not found: {MODEL_PATH}")
        logger.info("Please ensure the model file is in the same directory as enhanced_app.py")

    # Start the Flask development server
    logger.info("Starting Enhanced Pehchan AI Flask server...")
    logger.info("Features: Face Detection + 20-second Rolling Buffer + Prediction Smoothing")
    logger.info("Access the application at: http://localhost:5000")

    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )
