#!/usr/bin/env python3
"""
Gender Model Analysis Tool for Pehchan AI
This script analyzes your trained model's gender predictions in detail
"""

import os
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

def analyze_gender_model(model_path):
    """Analyze gender predictions from your trained model"""
    
    print("=" * 70)
    print("GENDER MODEL ANALYSIS - YOUR TRAINED MODEL")
    print("=" * 70)
    
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        return
    
    try:
        # Load your trained model
        print(f"📁 Loading your trained model: {model_path}")
        model = tf.keras.models.load_model(model_path)
        print("✅ Model loaded successfully!")
        
        # Analyze model structure for gender
        print("\n🔍 GENDER OUTPUT ANALYSIS:")
        analyze_model_structure(model)
        
        # Test with multiple samples to understand gender output
        print("\n🧪 TESTING GENDER PREDICTIONS:")
        test_gender_outputs(model)
        
        # Test both interpretations
        print("\n⚖️ TESTING BOTH INTERPRETATIONS:")
        test_interpretations(model)
        
        # Show recommendations
        print("\n💡 GENDER ACCURACY RECOMMENDATIONS:")
        show_gender_recommendations()
        
    except Exception as e:
        print(f"❌ Error analyzing model: {str(e)}")

def analyze_model_structure(model):
    """Analyze the model structure specifically for gender output"""
    
    print(f"   Model input shape: {model.input_shape}")
    print(f"   Model output shape: {model.output_shape}")
    
    if hasattr(model, 'output_names'):
        print(f"   Output names: {model.output_names}")
        
        for i, name in enumerate(model.output_names):
            if 'gender' in name.lower():
                print(f"   → Gender output found at index {i}: {name}")
            elif 'age' in name.lower():
                print(f"   → Age output found at index {i}: {name}")

def test_gender_outputs(model):
    """Test gender outputs with sample data"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        height = input_shape[1] if input_shape[1] is not None else 64
        width = input_shape[2] if input_shape[2] is not None else 64
        channels = input_shape[3] if input_shape[3] is not None else 3
        
        print(f"   Testing with input size: {height}x{width}x{channels}")
        
        # Test with 10 different samples
        gender_outputs = []
        
        for i in range(10):
            # Create random input (simulating preprocessed face image)
            sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
            
            # Make prediction
            predictions = model.predict(sample_input, verbose=0)
            
            # Extract gender output
            gender_output = extract_gender_output(predictions, model)
            gender_outputs.append(gender_output)
            
            print(f"   Sample {i+1:2d}: {gender_output}")
        
        # Analyze the pattern
        analyze_gender_pattern(gender_outputs)
        
    except Exception as e:
        print(f"   ❌ Error in gender testing: {str(e)}")

def extract_gender_output(predictions, model):
    """Extract gender output from model predictions"""
    
    try:
        if isinstance(predictions, list):
            # Multiple outputs - find gender
            if hasattr(model, 'output_names'):
                for i, name in enumerate(model.output_names):
                    if 'gender' in name.lower():
                        return {
                            'output_index': i,
                            'output_name': name,
                            'raw_value': float(predictions[i][0][0]) if len(predictions[i][0]) == 1 else predictions[i][0],
                            'shape': predictions[i].shape
                        }
            
            # If no gender name found, assume first output is gender (based on your model)
            return {
                'output_index': 0,
                'output_name': 'assumed_gender',
                'raw_value': float(predictions[0][0][0]) if len(predictions[0][0]) == 1 else predictions[0][0],
                'shape': predictions[0].shape
            }
        else:
            # Single output
            return {
                'output_index': 0,
                'output_name': 'single_output',
                'raw_value': float(predictions[0][1]) if len(predictions[0]) > 1 else float(predictions[0][0]),
                'shape': predictions.shape
            }
    
    except Exception as e:
        return {'error': str(e)}

def analyze_gender_pattern(gender_outputs):
    """Analyze the pattern in gender outputs"""
    
    print(f"\n   📊 GENDER OUTPUT PATTERN ANALYSIS:")
    
    # Extract raw values
    raw_values = []
    for output in gender_outputs:
        if 'raw_value' in output:
            if isinstance(output['raw_value'], (int, float)):
                raw_values.append(output['raw_value'])
    
    if raw_values:
        min_val = min(raw_values)
        max_val = max(raw_values)
        avg_val = sum(raw_values) / len(raw_values)
        
        print(f"      Range: {min_val:.4f} to {max_val:.4f}")
        print(f"      Average: {avg_val:.4f}")
        
        # Determine likely output type
        if all(0 <= val <= 1 for val in raw_values):
            print(f"      → Likely sigmoid output (0-1 range)")
            print(f"      → Interpretation: 0=Female, 1=Male OR 0=Male, 1=Female")
        elif all(-1 <= val <= 1 for val in raw_values):
            print(f"      → Likely tanh output (-1 to 1 range)")
        else:
            print(f"      → Unusual range - may need scaling")

def test_interpretations(model):
    """Test both gender interpretations with sample data"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        height = input_shape[1] if input_shape[1] is not None else 64
        width = input_shape[2] if input_shape[2] is not None else 64
        channels = input_shape[3] if input_shape[3] is not None else 3
        
        print(f"   Testing interpretations with 5 samples:")
        
        for i in range(5):
            sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
            predictions = model.predict(sample_input, verbose=0)
            
            # Extract gender value
            if isinstance(predictions, list):
                # Assume first output is gender based on your model structure
                gender_value = float(predictions[0][0][0])
            else:
                gender_value = float(predictions[0][1]) if len(predictions[0]) > 1 else float(predictions[0][0])
            
            # Test both interpretations
            interp_a = "Male" if gender_value > 0.5 else "Female"
            interp_b = "Female" if gender_value > 0.5 else "Male"
            
            print(f"      Sample {i+1}: Value={gender_value:.4f}")
            print(f"         Interpretation A (0=F, 1=M): {interp_a}")
            print(f"         Interpretation B (0=M, 1=F): {interp_b}")
            print()
    
    except Exception as e:
        print(f"   ❌ Error testing interpretations: {str(e)}")

def show_gender_recommendations():
    """Show specific recommendations for fixing gender accuracy"""
    
    print("""
🔧 GENDER ACCURACY FIXES FOR YOUR MODEL:

1. DETERMINE CORRECT INTERPRETATION:
   Your model outputs values between 0-1 for gender.
   You need to determine which interpretation matches your training:
   
   A) 0 = Female, 1 = Male (most common)
   B) 0 = Male, 1 = Female (less common)

2. TEST WITH KNOWN FACES:
   - Use the web interface with clearly male/female faces
   - Note which interpretation gives correct results
   - Update gender_config.py accordingly

3. QUICK FIX STEPS:
   a) Run: python quick_gender_fix.py
   b) Choose to switch interpretation if needed
   c) Restart enhanced_app.py
   d) Test again

4. MANUAL FIX:
   Edit gender_config.py:
   - If predictions are wrong: Change "A" to "B" or vice versa
   - Save file and restart server

5. VERIFY MODEL OUTPUT ORDER:
   Your model has outputs: [gender_output, age_output]
   Make sure enhanced_app.py uses the correct order.

📝 DEBUGGING CHECKLIST:
□ Model loads without errors
□ Gender values are between 0-1
□ Test with known male/female faces
□ Switch interpretation if predictions are inverted
□ Verify 20-second buffer shows stable results

🎯 EXPECTED RESULTS:
- Clear male faces → "Male" prediction
- Clear female faces → "Female" prediction  
- Confidence scores > 70%
- Stable predictions after 10-20 seconds
""")

def create_gender_test_script():
    """Create a simple test script for gender accuracy"""
    
    test_script = '''
# Quick Gender Test Script
# Run this to test your model's gender predictions

import numpy as np
import tensorflow as tf

# Load your model
model = tf.keras.models.load_model("age_gender_model3 .keras")

# Test with sample input
sample = np.random.random((1, 64, 64, 3)).astype(np.float32)
predictions = model.predict(sample)

# Extract gender (first output)
gender_value = float(predictions[0][0][0])

print(f"Gender value: {gender_value:.4f}")
print(f"Interpretation A: {'Male' if gender_value > 0.5 else 'Female'}")
print(f"Interpretation B: {'Female' if gender_value > 0.5 else 'Male'}")
print("Test with real faces to see which interpretation is correct!")
'''
    
    with open("test_gender_quick.py", "w") as f:
        f.write(test_script)
    
    print("\n📄 Created test_gender_quick.py for quick testing")

if __name__ == "__main__":
    model_path = "age_gender_model3 .keras"  # Your model file
    
    print("🔍 Analyzing your trained model's gender predictions...")
    analyze_gender_model(model_path)
    create_gender_test_script()
    
    print("\n✅ Gender analysis complete!")
    print("\n🎯 Next steps:")
    print("1. Review the analysis above")
    print("2. Test with real faces in the web interface")
    print("3. If gender is wrong, run: python quick_gender_fix.py")
    print("4. Switch interpretation and test again")
    print("5. Verify results are now accurate")
