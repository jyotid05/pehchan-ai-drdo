
# Quick Gender Test Script
# Run this to test your model's gender predictions

import numpy as np
import tensorflow as tf

# Load your model
model = tf.keras.models.load_model("age_gender_model3 .keras")

# Test with sample input
sample = np.random.random((1, 64, 64, 3)).astype(np.float32)
predictions = model.predict(sample)

# Extract gender (first output)
gender_value = float(predictions[0][0][0])

print(f"Gender value: {gender_value:.4f}")
print(f"Interpretation A: {'Male' if gender_value > 0.5 else 'Female'}")
print(f"Interpretation B: {'Female' if gender_value > 0.5 else 'Male'}")
print("Test with real faces to see which interpretation is correct!")
