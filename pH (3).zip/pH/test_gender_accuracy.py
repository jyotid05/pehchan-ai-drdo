#!/usr/bin/env python3
"""
Gender Accuracy Testing Tool for Pehchan AI
This script helps you test and fix gender prediction accuracy
"""

import os
import sys
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

def test_gender_with_model(model_path, test_images_dir=None):
    """Test gender predictions with your actual model"""
    
    print("=" * 60)
    print("GENDER ACCURACY TESTING")
    print("=" * 60)
    
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        return
    
    try:
        # Load model
        print(f"📁 Loading model from: {model_path}")
        model = tf.keras.models.load_model(model_path)
        print("✅ Model loaded successfully!")
        
        # Test with sample data first
        print("\n🧪 TESTING WITH RANDOM DATA:")
        test_with_random_data(model)
        
        # Test with real images if directory provided
        if test_images_dir and os.path.exists(test_images_dir):
            print(f"\n📸 TESTING WITH REAL IMAGES FROM: {test_images_dir}")
            test_with_real_images(model, test_images_dir)
        else:
            print("\n💡 To test with real images:")
            print("   1. Create a folder with test images")
            print("   2. Name files like: male_1.jpg, female_1.jpg, etc.")
            print("   3. Run: python test_gender_accuracy.py path/to/images")
        
        # Show interpretation guide
        show_interpretation_guide()
        
    except Exception as e:
        print(f"❌ Error testing model: {str(e)}")

def test_with_random_data(model):
    """Test with random data to understand output format"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        if len(input_shape) >= 4:
            batch, height, width, channels = input_shape
            if height is None or width is None:
                height, width = 224, 224
            if channels is None:
                channels = 3
            
            print(f"   Model expects input: {height}x{width}x{channels}")
            
            # Test multiple samples
            for i in range(3):
                print(f"\n   Sample {i+1}:")
                
                # Create random input
                sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
                
                # Make prediction
                predictions = model.predict(sample_input, verbose=0)
                
                # Analyze predictions
                gender_info = analyze_gender_predictions(predictions)
                print(f"      Raw output: {gender_info}")
                
                # Test both interpretations
                interpretations = test_both_interpretations(predictions)
                for interp_name, result in interpretations.items():
                    print(f"      {interp_name}: {result}")
                    
    except Exception as e:
        print(f"   ❌ Error in random data test: {str(e)}")

def analyze_gender_predictions(predictions):
    """Analyze the raw predictions to understand format"""
    
    if isinstance(predictions, list):
        return f"Multiple outputs: {[pred.shape for pred in predictions]}"
    else:
        return f"Single output: {predictions.shape}, values: {predictions[0]}"

def test_both_interpretations(predictions):
    """Test both gender interpretations"""
    
    interpretations = {}
    
    try:
        if isinstance(predictions, list) and len(predictions) >= 2:
            # Assume second output is gender
            gender_output = predictions[1][0]
            
            if len(gender_output) == 2:
                # Binary classification
                probs = gender_output
                pred_class = np.argmax(probs)
                confidence = np.max(probs)
                
                interp_a = "Male" if pred_class == 1 else "Female"
                interp_b = "Female" if pred_class == 1 else "Male"
                
                interpretations["Interpretation A (0=F, 1=M)"] = f"{interp_a} ({confidence:.3f})"
                interpretations["Interpretation B (0=M, 1=F)"] = f"{interp_b} ({confidence:.3f})"
                
            elif len(gender_output) == 1:
                # Single value
                value = gender_output[0]
                
                interp_a = "Male" if value > 0.5 else "Female"
                interp_b = "Female" if value > 0.5 else "Male"
                
                interpretations["Interpretation A (0=F, 1=M)"] = f"{interp_a} ({value:.3f})"
                interpretations["Interpretation B (0=M, 1=F)"] = f"{interp_b} ({value:.3f})"
        
        elif hasattr(predictions, 'shape') and len(predictions.shape) == 2:
            # Single output with multiple values
            if predictions.shape[1] >= 2:
                gender_value = predictions[0][1]
                
                interp_a = "Male" if gender_value > 0.5 else "Female"
                interp_b = "Female" if gender_value > 0.5 else "Male"
                
                interpretations["Interpretation A (0=F, 1=M)"] = f"{interp_a} ({gender_value:.3f})"
                interpretations["Interpretation B (0=M, 1=F)"] = f"{interp_b} ({gender_value:.3f})"
        
    except Exception as e:
        interpretations["Error"] = str(e)
    
    return interpretations

def test_with_real_images(model, images_dir):
    """Test with real images if available"""
    
    try:
        image_files = [f for f in os.listdir(images_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
        
        if not image_files:
            print("   No image files found")
            return
        
        print(f"   Found {len(image_files)} images")
        
        for img_file in image_files[:5]:  # Test first 5 images
            print(f"\n   Testing: {img_file}")
            
            # Determine expected gender from filename
            expected_gender = None
            if 'male' in img_file.lower() and 'female' not in img_file.lower():
                expected_gender = "Male"
            elif 'female' in img_file.lower():
                expected_gender = "Female"
            
            # Load and preprocess image
            img_path = os.path.join(images_dir, img_file)
            processed_img = preprocess_image_for_model(img_path, model)
            
            if processed_img is not None:
                # Make prediction
                predictions = model.predict(processed_img, verbose=0)
                
                # Test interpretations
                interpretations = test_both_interpretations(predictions)
                
                print(f"      Expected: {expected_gender}")
                for interp_name, result in interpretations.items():
                    correct = "✅" if expected_gender and expected_gender in result else "❌" if expected_gender else "❓"
                    print(f"      {interp_name}: {result} {correct}")
                    
    except Exception as e:
        print(f"   ❌ Error testing real images: {str(e)}")

def preprocess_image_for_model(img_path, model):
    """Preprocess image for model input"""
    
    try:
        # Get model input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        height = input_shape[1] if input_shape[1] is not None else 224
        width = input_shape[2] if input_shape[2] is not None else 224
        
        # Load image
        img = Image.open(img_path)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Resize
        img_resized = img.resize((width, height))
        img_array = np.array(img_resized)
        
        # Normalize (try standard 0-1 normalization)
        img_normalized = img_array.astype(np.float32) / 255.0
        
        # Add batch dimension
        img_batch = np.expand_dims(img_normalized, axis=0)
        
        return img_batch
        
    except Exception as e:
        print(f"      Error preprocessing {img_path}: {str(e)}")
        return None

def show_interpretation_guide():
    """Show guide for fixing gender predictions"""
    
    print("\n" + "=" * 60)
    print("GENDER INTERPRETATION GUIDE")
    print("=" * 60)
    
    print("""
🔧 HOW TO FIX GENDER PREDICTIONS:

1. ANALYZE THE RESULTS ABOVE:
   - Look at the "Interpretation A" vs "Interpretation B" results
   - If you tested with real images, see which interpretation is correct

2. UPDATE THE CONFIGURATION:
   - Edit gender_config.py
   - Change GENDER_INTERPRETATION = "A" to "B" (or vice versa)
   - If interpretation A is correct, keep it as "A"
   - If interpretation B is correct, change it to "B"

3. RESTART THE SERVER:
   - Stop the enhanced_app.py
   - Start it again: python enhanced_app.py
   - The new interpretation will be used automatically

4. TEST AGAIN:
   - Use the web interface to test with real faces
   - Verify that gender predictions are now correct

📝 EXAMPLE:
   If "Interpretation B" gives correct results for your test images:
   
   # In gender_config.py, change this line:
   GENDER_INTERPRETATION = "A"
   
   # To this:
   GENDER_INTERPRETATION = "B"

🎯 COMMON ISSUES:
   - Model outputs [Female_prob, Male_prob] but you expect [Male_prob, Female_prob]
   - Model outputs single value where 0=Male, 1=Female (instead of 0=Female, 1=Male)
   - Training data had different label encoding than expected

💡 TIP:
   Test with images where you're 100% sure of the gender (clear male/female faces)
   to determine which interpretation is correct.
""")

if __name__ == "__main__":
    model_path = "age_gender_model3 .keras"  # Note: space in filename
    test_images_dir = None
    
    # Check for command line arguments
    if len(sys.argv) > 1:
        test_images_dir = sys.argv[1]
    
    print("🔍 Starting gender accuracy testing...")
    test_gender_with_model(model_path, test_images_dir)
    
    print("\n✅ Testing complete!")
    print("\n🎯 Next steps:")
    print("1. Review the interpretation results above")
    print("2. Update gender_config.py with the correct interpretation")
    print("3. Restart enhanced_app.py")
    print("4. Test the web interface with real faces")
    
    if not test_images_dir:
        print("\n💡 For better testing, run with test images:")
        print("   python test_gender_accuracy.py path/to/test/images")
        print("   (Name files like: male_1.jpg, female_1.jpg, etc.)")
