#!/usr/bin/env python3
"""
Age Group Debugging Tool for Pehchan AI
This script analyzes age predictions and helps fix age group categorization
"""

import os
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2

def analyze_age_predictions(model_path):
    """Analyze age prediction behavior and group mapping"""
    
    print("=" * 60)
    print("AGE GROUP PREDICTION ANALYSIS")
    print("=" * 60)
    
    if not os.path.exists(model_path):
        print(f"❌ Model file not found: {model_path}")
        return
    
    try:
        # Load model
        print(f"📁 Loading model from: {model_path}")
        model = tf.keras.models.load_model(model_path)
        print("✅ Model loaded successfully!")
        
        # Analyze model outputs for age
        print("\n🔍 AGE OUTPUT ANALYSIS:")
        analyze_age_output_format(model)
        
        # Test with sample data
        print("\n🧪 TESTING AGE PREDICTIONS:")
        test_age_predictions(model)
        
        # Test age group mapping
        print("\n📊 TESTING AGE GROUP MAPPING:")
        test_age_group_mapping()
        
        # Show recommendations
        print("\n💡 AGE PREDICTION RECOMMENDATIONS:")
        show_age_recommendations()
        
    except Exception as e:
        print(f"❌ Error analyzing model: {str(e)}")

def analyze_age_output_format(model):
    """Analyze model outputs specifically for age information"""
    
    # Get output information
    if hasattr(model, 'output_shape'):
        if isinstance(model.output_shape, list):
            print(f"   Multiple outputs detected: {len(model.output_shape)}")
            for i, shape in enumerate(model.output_shape):
                output_name = model.output_names[i] if hasattr(model, 'output_names') else f"output_{i}"
                print(f"   Output {i} ({output_name}): {shape}")
                analyze_single_output_for_age(shape, output_name, i)
        else:
            print(f"   Single output: {model.output_shape}")
            analyze_single_output_for_age(model.output_shape, "single_output", 0)

def analyze_single_output_for_age(shape, name, index):
    """Analyze what each output might represent for age"""
    
    if len(shape) >= 2:
        output_size = shape[-1]
        
        if output_size == 1:
            if "age" in name.lower():
                print(f"      → {name}: Single value - likely age regression (direct age prediction)")
            else:
                print(f"      → {name}: Single value - could be age or other metric")
        elif 2 <= output_size <= 10:
            print(f"      → {name}: {output_size} values - might be age groups/ranges")
        elif output_size > 10:
            print(f"      → {name}: {output_size} values - likely age classification (each class = age range)")
        else:
            print(f"      → {name}: Unclear format")

def test_age_predictions(model):
    """Test age predictions with sample data"""
    
    try:
        # Get input shape
        if isinstance(model.input_shape, list):
            input_shape = model.input_shape[0]
        else:
            input_shape = model.input_shape
        
        if len(input_shape) >= 4:
            batch, height, width, channels = input_shape
            if height is None or width is None:
                height, width = 64, 64  # Your model uses 64x64
            if channels is None:
                channels = 3
            
            print(f"   Model expects: {height}x{width}x{channels}")
            
            # Test with multiple samples
            for i in range(5):
                print(f"\n   Sample {i+1}:")
                sample_input = np.random.random((1, height, width, channels)).astype(np.float32)
                
                # Make prediction
                predictions = model.predict(sample_input, verbose=0)
                
                # Analyze age predictions
                age_info = extract_age_info(predictions, model)
                print(f"      Raw age output: {age_info}")
                
                # Test age group mapping
                if age_info['predicted_age'] is not None:
                    age_group = map_age_to_group(age_info['predicted_age'])
                    print(f"      Mapped to group: {age_group}")
                    
    except Exception as e:
        print(f"   ❌ Error in age testing: {str(e)}")

def extract_age_info(predictions, model):
    """Extract age information from model predictions"""
    
    age_info = {
        'predicted_age': None,
        'raw_output': None,
        'output_type': 'unknown'
    }
    
    try:
        if isinstance(predictions, list):
            # Multiple outputs - find age output
            for i, pred in enumerate(predictions):
                output_name = model.output_names[i] if hasattr(model, 'output_names') else f"output_{i}"
                
                if "age" in output_name.lower():
                    age_info['raw_output'] = pred[0]
                    age_info['output_type'] = f"multiple_outputs_{output_name}"
                    
                    if len(pred[0].shape) == 0 or (len(pred[0].shape) == 1 and len(pred[0]) == 1):
                        # Single age value (regression)
                        age_info['predicted_age'] = float(pred[0]) if len(pred[0].shape) == 0 else float(pred[0][0])
                    elif len(pred[0]) > 1:
                        # Multiple values - could be age classes
                        age_class = np.argmax(pred[0])
                        age_info['predicted_age'] = convert_age_class_to_numeric(age_class, len(pred[0]))
                    break
            
            # If no age output found, use first output
            if age_info['predicted_age'] is None and len(predictions) > 0:
                age_info['raw_output'] = predictions[0][0]
                age_info['output_type'] = "first_output_assumed_age"
                if len(predictions[0][0].shape) == 0:
                    age_info['predicted_age'] = float(predictions[0][0])
                elif len(predictions[0][0]) == 1:
                    age_info['predicted_age'] = float(predictions[0][0][0])
        
        else:
            # Single output
            age_info['raw_output'] = predictions[0]
            age_info['output_type'] = "single_output"
            
            if len(predictions[0]) == 1:
                # Single age value
                age_info['predicted_age'] = float(predictions[0][0])
            elif len(predictions[0]) >= 2:
                # Multiple values - assume first is age
                age_info['predicted_age'] = float(predictions[0][0])
    
    except Exception as e:
        age_info['error'] = str(e)
    
    return age_info

def convert_age_class_to_numeric(age_class, total_classes):
    """Convert age class index to numeric age"""
    
    # Common age classification schemes
    if total_classes <= 8:
        # Broad age groups
        age_ranges = [
            (0, 10), (10, 20), (20, 30), (30, 40), 
            (40, 50), (50, 60), (60, 70), (70, 100)
        ]
    elif total_classes <= 20:
        # 5-year ranges
        age_ranges = [(i*5, (i+1)*5) for i in range(total_classes)]
    else:
        # 1-year or fine-grained classification
        age_ranges = [(i, i+1) for i in range(total_classes)]
    
    if 0 <= age_class < len(age_ranges):
        min_age, max_age = age_ranges[age_class]
        return (min_age + max_age) / 2
    else:
        return 30.0  # Default

def map_age_to_group(age):
    """Map numerical age to age group with emoji"""
    
    age_groups = {
        'Child': (3, 12, '🧒'),
        'Teenager': (13, 19, '🧑‍🎓'),
        'Young Adult': (20, 29, '👨‍💼'),
        'Adult': (30, 44, '🧔'),
        'Middle-aged': (45, 59, '👴'),
        'Senior': (60, 100, '👵')
    }
    
    for group_name, (min_age, max_age, emoji) in age_groups.items():
        if min_age <= age <= max_age:
            return f"{emoji} {group_name} (age {age:.1f})"
    
    return f"🤔 Unknown (age {age:.1f})"

def test_age_group_mapping():
    """Test the age group mapping with various ages"""
    
    test_ages = [5, 15, 25, 35, 50, 70, 2, 101, 30.5, 44.9, 45.1]
    
    print("   Testing age group mapping:")
    for age in test_ages:
        group = map_age_to_group(age)
        print(f"      Age {age:5.1f} → {group}")

def show_age_recommendations():
    """Show recommendations for fixing age predictions"""
    
    print("""
🔧 COMMON AGE PREDICTION ISSUES & FIXES:

1. AGE VALUES TOO HIGH/LOW:
   Problem: Model outputs unrealistic ages (e.g., 200, -10)
   Fix: Check if model outputs need scaling or different interpretation
   
2. AGE GROUPS WRONG:
   Problem: 25-year-old classified as "Senior"
   Fix: Verify age group boundaries in enhanced_app.py
   
3. AGE CLASSIFICATION VS REGRESSION:
   Problem: Model outputs age classes, not direct age
   Fix: Update prediction parsing to handle classification
   
4. PREPROCESSING MISMATCH:
   Problem: Model trained on different image format
   Fix: Verify normalization and input size (currently 64x64)

📝 DEBUGGING STEPS:
1. Check model output format above
2. Verify age values are reasonable (0-100)
3. Test age group mapping logic
4. Update enhanced_app.py if needed

🎯 EXPECTED BEHAVIOR:
- Age predictions: 0-100 years
- Age groups: Correct emoji and category
- Stability: Consistent over time
""")

def create_age_fix_script():
    """Create a script to fix common age issues"""
    
    fix_script = """
# AGE PREDICTION FIXES FOR enhanced_app.py

# 1. If age values are too high, add scaling:
age_pred = float(age_output[0][0]) * 100  # If model outputs 0-1 range

# 2. If age values are negative, add bounds:
age_pred = max(0, min(100, float(age_output[0][0])))

# 3. If model outputs age classes, use this:
age_class = np.argmax(age_output[0])
age_pred = convert_age_class_to_numeric(age_class)

# 4. Update age group mapping if boundaries are wrong:
age_groups = {
    'Child': (0, 12),      # Adjust these ranges
    'Teenager': (13, 19),
    'Young Adult': (20, 29),
    'Adult': (30, 44),
    'Middle-aged': (45, 59),
    'Senior': (60, 120)
}
"""
    
    with open("age_fix_suggestions.txt", "w") as f:
        f.write(fix_script)
    
    print("\n📄 Created age_fix_suggestions.txt with code snippets")

if __name__ == "__main__":
    model_path = "age_gender_model3 .keras"  # Note: space in filename
    
    print("🔍 Starting age group analysis...")
    analyze_age_predictions(model_path)
    create_age_fix_script()
    
    print("\n✅ Age analysis complete!")
    print("\n🎯 Next steps:")
    print("1. Review the analysis above")
    print("2. Check if age predictions are reasonable")
    print("3. Update enhanced_app.py if needed")
    print("4. Test the web interface")
    print("5. Run: python test_age_accuracy.py (if you have test images)")
